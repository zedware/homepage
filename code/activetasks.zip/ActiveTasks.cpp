///////////////////////////////////////////////////////////////////
// Copyleft @2001/11/16, uniware@chinaren.com
// uniware learn it from a book, but you can copy and try it.
// How to complier and link:
// 1. Under VC or EVC, create an empty project using the AppWizard.
// 2. Add all the three source files to the project.
// 3. Choose the platform and configre mode(debug/release), BUILD!
////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <windowsx.h>
#include <tchar.h>

#include "resource.h"

#define	 MY_WM_REFRESH	WM_USER + 100

HWND	hwndListTasks = NULL;
HWND	hwndActive	  = NULL;

TCHAR	szBuff[MAX_PATH];

BOOL CALLBACK DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		hwndListTasks = GetDlgItem(hwnd, IDC_LISTTASKS);
		SendMessage(hwnd, MY_WM_REFRESH, 0, 0);
		return TRUE;

	case WM_CTLCOLORDLG:

		SendMessage(hwnd, MY_WM_REFRESH, 0, 0);
		return FALSE;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDCANCEL:
		case IDOK:
			EndDialog(hwnd, 0);
			return TRUE;
		case IDC_ENDALLTASKS:
			{
				int		cbCount;

				cbCount = SendMessage(hwndListTasks, LB_GETCOUNT, 0, 0);
				for ( ; cbCount > 0; cbCount--)
				{
					SendMessage(hwndListTasks, LB_GETTEXT, (WPARAM)(cbCount), (LPARAM)(LPTSTR)(szBuff));
					hwndActive = FindWindow(NULL, szBuff);
					if (hwndActive != NULL)
					{
						SendMessage(hwndActive, WM_CLOSE, 0, 0);
					}
				}
			}
			return TRUE;

		case IDC_ENDTASK:
		case IDC_SWITCHTO:
			{
				int		cbCount;

				cbCount = (int)SendMessage(hwndListTasks, LB_GETCURSEL, 0, 0L);
				if (cbCount < 0)
				{
					MessageBox(hwnd, _T("����ѡ��һ������"), _T("����"), MB_OK | MB_ICONSTOP);
					return TRUE;
				}
				SendMessage(hwndListTasks,
							LB_GETTEXT,
							(WPARAM)SendMessage(hwndListTasks, LB_GETCURSEL, 0, 0L),
							(LPARAM)(LPTSTR)(szBuff));
				hwndActive = FindWindow(NULL, szBuff);
				if (hwndActive != NULL)
				{					
					SetForegroundWindow(hwndActive);
					if (LOWORD(wParam) == IDC_ENDTASK)
					{
						SendMessage(hwndActive, WM_CLOSE, 0, 0);
					}
				}
				SendMessage(hwnd, MY_WM_REFRESH, 0, 0);
			}
			break;
		}
		return TRUE;

	case MY_WM_REFRESH:
		
		SendMessage(GetDlgItem(hwnd, IDC_SWITCHTO), WM_SETFOCUS, 0, 0);
		SendMessage(hwndListTasks, LB_RESETCONTENT, 0, 0);
		hwndActive = GetWindow(hwnd, GW_HWNDFIRST);
		while (hwndActive != 0)
		{
			szBuff[0] = '\0';

			if ((hwndActive != hwnd)	&& 
				IsWindowVisible(hwndActive)	&&
				(!GetWindow(hwndActive, GW_OWNER))	&&
				(GetWindowText(hwndActive, szBuff, MAX_PATH) != 0) &&
				(lstrcmp(szBuff, _T("Desktop")) != 0) &&
				(lstrcmp(szBuff, _T("Program Manager")) != 0) &&	// NT
				(lstrcmp(szBuff, _T("MS_SIPBUTTON")) != 0)			// Pocket PC
				)
			{
				SendMessage(hwndListTasks, LB_ADDSTRING, 0, (LPARAM)(LPTSTR)(szBuff));
			}
			hwndActive = GetWindow(hwndActive, GW_HWNDNEXT);
		}

		return TRUE;

	default:
		
		return FALSE;
	}
}

#ifdef _WINDOWS 
int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR    lpCmdLine,
					int       nCmdShow)
#else
int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPTSTR    lpCmdLine,
					int       nCmdShow)
#endif
{
	int		nDlg;

	nDlg	= DialogBox((HINSTANCE)hInstance, MAKEINTRESOURCE(IDD_ActiveTasks), NULL, (DLGPROC)DlgProc);

	return 0;
}