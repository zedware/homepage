/* checkmemory.c
 * 
 * VERSION
 *	1.0.0
 *
 * NOTES
 * 	Memory management library for debug use only.
 *	Wrap malloc/realloc/calloc/strdup/free.
 * 
 * COPYRIGHT
 *	Copyright 2003, http://zedware.org.
 *
 *	Permission to use, copy, modify, and distribute this software and its
 *	documentation for any purpose, without fee, and without a written agreement
 *	is hereby granted, provided that the above copyright notice and this
 *	paragraph.
 *
 * IDENTIFICATION
 *	$Header: /checkmemory/checkmemory.c 3     03-10-04 23:22 Uniware $
 */

#include "checkmemory.h"

/* 
 * max path cannot be figured out easily on all platforms.
 * _MAX_PATH is defined under Windows.
 */
#define Z_MAX_PATH			(1024)

/*
 * seldom malloc so large a block in most programs.
 * (1024K)
 */
#define Z_TOO_LARGE_BLOCK	(1024 * 1024)	

#define Z_FILE_LEN		(32)	/* file name */
#define Z_LINE_LEN		(8)		/* line number */
#define Z_SIZE_LEN		(12)	/* memory size */
#define Z_PTR_LEN		(sizeof(void *) * 2 + 2)
								/* pointer: 0X00780E30 */
#define Z_PAD_LEN		(1)		/* field seperator */

#if defined(DEBUG) || defined(_DEBUG)

typedef struct tagMemory
{
	char	File[Z_FILE_LEN];
	int		Line;
	void	*Ptr;
	size_t	Size;
	struct tagMemory *Link;
} Z_MemoryType;

typedef struct tagMemoryDump
{
	char File[Z_FILE_LEN];
	char Pad1[Z_PAD_LEN];
	char Line[Z_LINE_LEN];
	char Pad2[Z_PAD_LEN];
	char Size[Z_SIZE_LEN];
	char Pad3[Z_PAD_LEN];
	char Ptr[Z_PTR_LEN];
	char CRLF[2];			/* CR LF */
} Z_MemoryDumpType;

/*
 * Global variables
 */
static long		g_BytesShared = 0;
static long		g_BytesUsed	  = 0;
static Z_MemoryType	*g_MemoryHead = NULL;
char g_DebugFile[Z_MAX_PATH];

/*
 * Static funcitons
 */
static void Z_PadSpace(char *Buffer, int Len);
static void Z_PadSpaceM(Z_MemoryDumpType *m);
static void Z_GetFileName(const char *File, char *Name, unsigned int Len);

/*
 * replace all bytes after string's end ('\0') to SPACE.
 */
static void 
Z_PadSpace(char *Buffer, int Len)
{
	char *p = Buffer;
	int  i = 0;

	z_assert(NULL != Buffer);

	while (*p != '\0' && i < Len)
	{
		p++;
		i++;
	}
	while (i < Len)
	{
		*p++ = ' ';
		i++;
	}
}

static void
Z_PadSpaceM(Z_MemoryDumpType *m)
{
	z_assert(NULL != m);
	
	Z_PadSpace(m->File, Z_FILE_LEN);
	Z_PadSpace(m->Pad1, Z_PAD_LEN);
	Z_PadSpace(m->Line, Z_LINE_LEN);
	Z_PadSpace(m->Pad2, Z_PAD_LEN);
	Z_PadSpace(m->Size, Z_SIZE_LEN);
	Z_PadSpace(m->Pad3, Z_PAD_LEN);
	Z_PadSpace(m->Ptr, Z_PTR_LEN);
	/*
	 * DOS and Windows use \r\n
	 * UNIX and Linux use \n
	 * Mac use \r
	 * But stdio deal with it for us. If using 0x0D 0x0A, 
	 * should write like:
	 *	m->CRLF[0] = 0x0D;
	 *	m->CRLF[1] = 0x0A;
	 */
	m->CRLF[0] = ' ';
	m->CRLF[1] = '\n';
}

/*
 * The full path name may be too long.
 * File name should be enough most of the time. 
 */
static void 
Z_GetFileName(const char *File, char *Name, unsigned int Len)
{
	char *p = NULL;

	if ( NULL == File || NULL == Name || 0 == Len )
		return;

#if defined(WIN32) || defined(Windows)
	p = strrchr(File, '\\');
#endif	
	if (NULL == p)
		p = strchr(File, '/');
	
	if ( NULL == p )
	{
		strncpy( Name, File, Len - 1 );
	}
	else
	{
		strncpy( Name, p + 1, Len - 1 );
	}
	Name[Len - 1] = '\0';
}

void 
Z_MallocMemory(void *Ptr, size_t Size,	const char *File, int Line)
{
	Z_MemoryType *pNode;

	if (NULL == Ptr)
		return;

	pNode = (Z_MemoryType *)malloc(sizeof(Z_MemoryType));
	if (NULL == pNode)
	{
		z_assert(0);
		return;
	}

	Z_GetFileName(File, pNode->File, Z_FILE_LEN);
	pNode->Line = Line;
	pNode->Size = Size;
	pNode->Ptr  = Ptr;
	pNode->Link = NULL;

	if (NULL == g_MemoryHead)
	{
		g_MemoryHead = pNode;
	}
	else
	{
		pNode->Link = g_MemoryHead;
		g_MemoryHead = pNode;
	}
	g_BytesUsed += Size;
}

void 
Z_FreeMemory(void *Ptr)
{
	Z_MemoryType *pBack;
	Z_MemoryType *pNode;

	pBack = NULL;
	pNode = g_MemoryHead;
	while (NULL != pNode)
	{
		if (pNode->Ptr == Ptr)
		{
			if (g_MemoryHead == pNode)
				g_MemoryHead = pNode->Link;
			else
				pBack->Link = pNode->Link;
	
			g_BytesUsed -= pNode->Size;
			free(pNode);		
			break;
		}

		pBack = pNode;
		pNode = pNode->Link;
	}
}

void 
Z_MemoryUse(unsigned long *BytesShared, unsigned long *BytesUsed)
{
	z_assert(NULL != BytesShared);
	z_assert(NULL != BytesUsed);

	*BytesShared = g_BytesShared;
	*BytesUsed = g_BytesUsed;
}

int 
Z_MemoryDump(void)
{
	Z_MemoryType *pNode, *pLink;
	Z_MemoryDumpType m;
	FILE *fp = NULL;

	pNode = g_MemoryHead;
	if (NULL != pNode)
	{
		/* memory leak found */
		z_assert(0);

		if (g_DebugFile[0] == '\0')
		{
			fp = stdout;
		}
		else
		{
			fp = fopen(g_DebugFile, "a+");
			if (NULL == fp)
				return -1;
		}
	}

	while (NULL != pNode)
	{
		memset(&m, '\0', sizeof(m));
		strncpy(m.File, pNode->File, Z_FILE_LEN);
		sprintf(m.Line, "%*d", Z_LINE_LEN, pNode->Line);
		sprintf(m.Size, "%*d", Z_SIZE_LEN, pNode->Size);
		sprintf(m.Ptr, "0X%0*X", Z_PTR_LEN - 2, pNode->Ptr);
		Z_PadSpaceM(&m);

		if (1 != fwrite(&m, sizeof(m), 1, fp)) 
			return -1;

		pLink = pNode->Link;
		free(pNode);		
		pNode = pLink;
	}

	g_BytesUsed	  = 0;
	g_BytesShared = 0;
	g_MemoryHead  = NULL;

	if (fp != stdout && NULL != fp)
		fclose(fp);

	return 0;
}

void *
Z_MallocDebug(size_t Size, const char *File, int Line)
{
	void *Ptr;

	if (Size == 0)
		return NULL;

	z_assert(Size <= Z_TOO_LARGE_BLOCK);

	Ptr = malloc(Size);
	if (NULL == Ptr)
		return NULL;

	memset(Ptr, 0, Size);

	Z_MallocMemory(Ptr, Size, File, Line);

	return Ptr;
}

void 
Z_FreeDebug(void *Ptr)
{
	if (NULL == Ptr)
		return;
	free(Ptr);

	Z_FreeMemory(Ptr);
}

void 
Z_FreeAndSetDebug(void **Ptr)
{
	if (NULL == *Ptr)
		return;

	free(*Ptr);

	Z_FreeMemory(*Ptr);

	*Ptr = NULL;
}

void *
Z_ReallocDebug(void *Ptr, size_t Size, const char *File, int Line)
{
	void *p;

	/* Ptr may be NULL */

	z_assert(Size <= Z_TOO_LARGE_BLOCK);

	p = realloc(Ptr, Size);
	if (NULL == p)
		return p;

	/* record previous pointer as freed */
	Z_FreeMemory(Ptr);
	Z_MallocMemory(p, Size, File, Line);

	return p;
}

void *
Z_CallocDebug(size_t Num, size_t Size, const char *File, int Line)
{
	void *p;

	if (Num == 0 || Size == 0)
		return NULL;

	z_assert(Num * Size <= Z_TOO_LARGE_BLOCK);
		
	p = calloc(Num, Size);
	if (NULL == p)
		return p;

	Z_MallocMemory(p, Num * Size, File, Line);

	return p;
}

char *
Z_StrdupDebug(const char *Source, const char *File, int Line)
{
	char *p;

	if (NULL == Source)
		return NULL;

	p = strdup(Source);
	if (NULL == p)
		return p;

	Z_MallocMemory(p, strlen(Source) + 1, File, Line);

	return p;
}

#endif /* DEBUG || _DEBUG */

void 
Z_FreeAndSet(void **Ptr)
{
	if (NULL == *Ptr)
		return;

	free(*Ptr);

	*Ptr = NULL;
}
