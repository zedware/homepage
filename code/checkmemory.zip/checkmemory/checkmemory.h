/* checkmemory.h
 * 
 * VERSION
 *	1.0.0
 *
 * NOTES
 * 	Memory management library for debug use only.
 * 	Put the following lines into a common head file.
 * 
	#if defined(DEBUG) || defined(_DEBUG)
	#define malloc(Size)		Z_MallocDebug(Size, __FILE__, __LINE__)
	#define realloc(p, Size)	Z_ReallocDebug(p, Size, __FILE__, __LINE__)
	#define calloc(Num, Size)	Z_CallocDebug(Num, Size, __FILE__, __LINE__)
	#define strdup(Source)		Z_StrdupDebug(Source, __FILE__, __LINE__)
	#define free(p)				Z_FreeDebug(p)
	#define free_ex(p)			Z_FreeAndSetDebug((void **)&(p))
	#else
	#define free_ex(p)			Z_FreeAndSet(p)
	#endif
 *
 * COPYRIGHT
 *	Copyright 2003, http://zedware.org.
 *
 *	Permission to use, copy, modify, and distribute this software and its
 *	documentation for any purpose, without fee, and without a written agreement
 *	is hereby granted, provided that the above copyright notice and this
 *	paragraph.
 *
 * IDENTIFICATION
 *	$Header: /checkmemory/checkmemory.h 2     03-10-04 22:28 Uniware $
 */

#ifndef CHECK_MEMORY_H
#define CHECK_MEMORY_H

#include <ctype.h>
#include <stddef.h>
#include <string.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#ifdef Z_HAVE_ASSERT
#define z_assert	assert
#else
#define z_assert	
#endif /* Z_HAVE_ASSERT */

#if defined(DEBUG) || defined(_DEBUG)

void Z_MemoryUse(unsigned long *, unsigned long *);
int  Z_MemoryDump(void);

void Z_MallocMemory(void *Ptr, size_t Size, const char *File, int Line);
void Z_FreeMemory(void *Ptr);

void *Z_MallocDebug(size_t Size, const char * File, int Line);
void *Z_ReallocDebug(void *Ptr, size_t Size, const char * File, int Line);
void *Z_CallocDebug(size_t Num, size_t Size, const char * File, int Line);
char *Z_StrdupDebug(const char *Source, const char * File, int Line);
void Z_FreeDebug(void *p);
void Z_FreeAndSetDebug(void **pp);

#endif /* DEBUG || _DEBUG */

void Z_FreeAndSet(void **Ptr);

#endif /* CHECK_MEMORY_H */
