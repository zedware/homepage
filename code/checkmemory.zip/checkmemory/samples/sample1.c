/* sample1.c
 *
 * VERSION
 *	1.0.0
 *
 * NOTES
 * 	Sample of using checkmemory library.
 *	Under Windows, open sample1.dsw with MS VC++ and build.
 *	Under UNIX/LINUX, execute:
 *		gcc -DDEBUG sample1.c ../checkmemory.c 
 *
 * COPYRIGHT
 *	Copyright 2003, http://zedware.org.
 *
 *	Permission to use, copy, modify, and distribute this software and its
 *	documentation for any purpose, without fee, and without a written agreement
 *	is hereby granted, provided that the above copyright notice and this
 *	paragraph.
 *
 * IDENTIFICATION
 *	$Header: /checkmemory/samples/sample1.c 3     03-10-04 23:31 Uniware $
 */
 
#include "sample1.h" 

int
main(void)
{
	int	 rv = 1;
	char *p = NULL, *tmp = NULL;
	char *q = NULL;
	char *str = NULL;
	
	p = malloc(1024);
	if (NULL == p)
		goto error_exit;
	
	tmp = realloc(p, 1024 * 2);
	if (NULL == tmp)
		goto error_exit;
	p = tmp;
	
	q = calloc(1024, 1);
	if (NULL == q)
		goto error_exit;
	
	str = strdup("Hello, World!");
	if (NULL == str)
		goto error_exit;

	rv = 0;
	
error_exit:

	/* 
	 * Should free space.
	 */
#if 0
	if (p)
		free(p);
	if (q)
		free(q);
	if (str)
		free(str);
#endif 

#if defined(DEBUG) || defined(_DEBUG)
	Z_MemoryDump();
#endif	

	return rv;
}
