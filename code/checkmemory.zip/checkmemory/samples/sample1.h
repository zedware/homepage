/* sample1.h
 *
 * VERSION
 *	1.0.0
 *
 * NOTES
 * 	Sample of using checkmemory library.
 *
 * COPYRIGHT
 *	Copyright 2003, http://zedware.org.
 *
 *	Permission to use, copy, modify, and distribute this software and its
 *	documentation for any purpose, without fee, and without a written agreement
 *	is hereby granted, provided that the above copyright notice and this
 *	paragraph.
 *
 * IDENTIFICATION
 *	$Header: /checkmemory/samples/sample1.h 2     03-10-04 23:22 Uniware $
 */
#ifndef Z_SAMPLE1_H
#define Z_SAMPLE1_h

#include "../checkmemory.h"

#if defined(DEBUG) || defined(_DEBUG)
#define malloc(Size)		Z_MallocDebug(Size, __FILE__, __LINE__)
#define realloc(p, Size)	Z_ReallocDebug(p, Size, __FILE__, __LINE__)
#define calloc(Num, Size)	Z_CallocDebug(Num, Size, __FILE__, __LINE__)
#define strdup(Source)		Z_StrdupDebug(Source, __FILE__, __LINE__)
#define free(p)				Z_FreeDebug(p)
#define free_ex(p)			Z_FreeAndSetDebug((void **)&(p))
#else
#define free_ex(p)			Z_FreeAndSet(p)
#endif

#endif /* Z_SAMPLE1_H */ 
