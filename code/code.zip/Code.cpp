
#include "stdafx.h"
#include "Code.h"

INT CMyCode::WideCharToChar(LPCWSTR lpwzStr, LPSTR lpszStr)
{
	INT nSize;
	INT	nRet;

	if ( NULL == lpwzStr || NULL == lpszStr)
		return -1;

	nSize = WideCharToMultiByte(CP_ACP, 0, lpwzStr, -1, NULL, 0, NULL, NULL);
	if ( 0 == nSize)
		return -1;

	nRet = WideCharToMultiByte(CP_ACP, 0, lpwzStr, -1, lpszStr, nSize, NULL, NULL);
	if ( 0 == nRet)
		return -1;

	return nRet;
}

INT CMyCode::WideCharToChar(LPCWSTR lpwzStr, LPSTR *lplpszStr)
{
	INT nSize;
	INT	nRet;

	if ( NULL == lpwzStr || NULL == lplpszStr)
		return -1;

	nSize = WideCharToMultiByte(CP_ACP, 0, lpwzStr, -1, NULL, 0, NULL, NULL);
	if ( 0 == nSize)
		return -1;

	*lplpszStr = new CHAR[nSize];
	
	nRet = WideCharToMultiByte(CP_ACP, 0, lpwzStr, -1, *lplpszStr, nSize, NULL, NULL);
	if ( 0 == nRet)
		return -1;

	return nRet;
}

INT CMyCode::CharToWideChar(LPCSTR lpszStr, LPWSTR *lplpwzStr)
{
	INT nSize;
	INT	nRet;

	if ( NULL == lpszStr || NULL == lplpwzStr)
		return -1;

	nSize = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED,	lpszStr, -1, NULL, 0); 
	if ( 0 == nSize)
		return -1;

	(*lplpwzStr) = new WCHAR[nSize];
	nRet = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, lpszStr, -1, *lplpwzStr, nSize); 
	if ( 0 == nRet)
		return -1;

	return nRet;
}

INT CMyCode::CharToWideChar(LPCSTR lpszStr, LPWSTR lpwzStr)
{
	INT nSize;
	INT	nRet;

	if ( NULL == lpszStr || NULL == lpwzStr)
		return -1;

	nSize = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, lpszStr, -1, NULL, 0); 
	if ( 0 == nSize)
		return -1;

	nRet = MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, lpszStr, -1, lpwzStr, nSize);
	if ( 0 == nRet)
		return -1;

	return nRet;
}

INT CMyCode::CharToTChar(LPCSTR lpszStr, LPTSTR *lplptzStr)
{
#ifdef _UNICODE
	return CharToWideChar(lpszStr, lplptzStr);
#else
	ASSERT(NULL != lplptzStr);
	(*lplptzStr) = new CHAR[(strlen(lpszStr) + 1) * sizeof(CHAR)];
	strcpy(*lplptzStr, lpszStr);
	return 0;
#endif
}

INT CMyCode::CharToTChar(LPCSTR lpszStr, LPTSTR lptzStr)
{
#ifdef _UNICODE
	return CharToWideChar(lpszStr, lptzStr);
#else
	strcpy(lptzStr, lpszStr);
	return 0;
#endif
}

INT CMyCode::TCharToChar(
	LPCTSTR lptzStr,
	LPSTR *lpszStr
	)
{
#ifdef _UNICODE
	return WideCharToChar(lptzStr, lpszStr);
#else
	ASSERT(NULL != lpszStr);

	(*lpszStr) = new CHAR[(strlen(lptzStr) + 1) * sizeof(CHAR)];
	strcpy(*lpszStr, lptzStr);
	return 0;
#endif
}

INT CMyCode::TCharToChar(
	LPCTSTR lptzStr,
	LPSTR lpszStr
	)
{
#ifdef _UNICODE
	return WideCharToChar(lptzStr, lpszStr);
#else
	strcpy(lpszStr, lptzStr);
	return 0;
#endif
}

// end of file