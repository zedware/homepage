
///////////////////////////////////////////////////////////
// Copyleft @2002, uniware@chinaren.com
// Simple version of code convert class.
// You can use if freely to convert between UNICODE16 
//  and ANSI.
// Functions defined in Class MyCode are all static,
//  you can use them without construct an object. 
///////////////////////////////////////////////////////////

#ifndef _H_MY_CODE
#define _H_MY_CODE

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMyCode : public CObject
{
public:
	CMyCode();
	~CMyCode();

// Attributes
public:

// Operations
public:
	static INT WideCharToChar(LPCWSTR lpwzStr, LPSTR *lplpszStr);
	static INT WideCharToChar(LPCWSTR lpwzStr, LPSTR lpszStr);

	static INT CharToWideChar(LPCSTR lpszStr, LPWSTR *lplpwzStr);
	static INT CharToWideChar(LPCSTR lpszStr, LPWSTR lpwzStr);
	
	static INT CharToTChar(LPCSTR lpszStr, LPTSTR *lplptzStr);
	static INT CharToTChar(LPCSTR lpszStr, LPTSTR lptzStr);

	static INT TCharToChar(LPCTSTR lptzStr, LPSTR *lplpszStr);
	static INT TCharToChar(LPCTSTR lptzStr, LPSTR lpszStr);
};

#endif // _H_MY_CODE