/*  This file was written by Amir Israeli , July 2000   Email: israelaq@walla.co.il  
No warranty of any kind . Dont remove this header . Thanks.
*/
// MemFileEx.cpp : implementation file
//

#include "stdafx.h"
#include "MemFileEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemFileEx

CMemFileEx::CMemFileEx()
{
	cbSize = 0;
}

CMemFileEx::~CMemFileEx()
{
}


/////////////////////////////////////////////////////////////////////////////
// CMemFileEx member functions

BOOL CMemFileEx::LoadResource( LPCTSTR lpszName, LPCTSTR lpszType)
{
	//already contains a buffer in use 
	//(you can Detach it and free the buffer ...
	ASSERT(m_lpBuffer==NULL);//must be null

	HINSTANCE hInst = AfxGetResourceHandle(); 
	HRSRC hRsrc = ::FindResource( hInst, lpszName, lpszType);
	if (!hRsrc)  return FALSE;
	cbSize = ::SizeofResource(hInst, hRsrc); 
	LPBYTE lpRsrc = (LPBYTE) ::LoadResource( hInst, hRsrc); 
	Attach( lpRsrc, cbSize, 0);
	return TRUE;
}

//Functions such as LoadResource DONT return HGLOBAL but
//generic handle (they are defined as HGLOBAL for Win32 compatability 
//reasons only
BOOL CMemFileEx::CopyResourceToHGLOBAL( HGLOBAL *phGlobal, DWORD *pdwSize)
{
	*phGlobal = NULL; *pdwSize = 0; //initializing
	DWORD cbSize = GetFileSize();

	//if not contains a buffer or data length is 0 return FALSE 
	if ((!m_lpBuffer) || (!cbSize))
		return FALSE;

	*pdwSize = cbSize; //setting data size

	HGLOBAL hGlobal = ::GlobalAlloc( GHND, cbSize);
	if (!hGlobal)
		return FALSE;

	LPVOID lpData = ::GlobalLock(hGlobal);
	::CopyMemory( lpData, (LPVOID)m_lpBuffer, cbSize);

	::GlobalUnlock(hGlobal);
	*phGlobal = hGlobal;
	return TRUE;
}







