/*  This file was written by Amir Israeli , July 2000   Email: israelaq@walla.co.il  
No warranty of any kind . Dont remove this header . Thanks.
*/
#if !defined(AFX_MEMFILEEX_H__39FBD780_5C1D_11D4_B8C4_8809CE7C2F5F__INCLUDED_)
#define AFX_MEMFILEEX_H__39FBD780_5C1D_11D4_B8C4_8809CE7C2F5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MemFileEx.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMemFileEx window

class CMemFileEx : public CMemFile
{
public:
	CMemFileEx();
	virtual ~CMemFileEx();

	BOOL LoadResource( LPCTSTR lpszName, LPCTSTR lpszType);
	BOOL LoadResource( UINT uResourceID, LPCTSTR lpszType) {
		return LoadResource( MAKEINTRESOURCE(uResourceID), lpszType);
	}

	//get size of resource //also mentained in
	// m_nBufferSize a member of CMemFile
	DWORD GetFileSize() { return cbSize; }
	LPBYTE GetResourceData() { return m_lpBuffer; }

	BOOL CopyResourceToHGLOBAL( HGLOBAL *phGlobal, DWORD *pdwSize);
protected:

	DWORD   cbSize;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEMFILEEX_H__39FBD780_5C1D_11D4_B8C4_8809CE7C2F5F__INCLUDED_)
