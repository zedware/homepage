/*  This file was written by Amir Israeli , July 2000   Email: israelaq@walla.co.il  
No warranty of any kind . Dont remove this header . Thanks.
*/
// Message.cpp: implementation of the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Message.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMessage::CMessage()
{
}
CMessage::~CMessage()
{
}

HWND CMessage::GetWindow(CWnd *pWnd)
{
	if ((!pWnd) || (!::IsWindow(pWnd->GetSafeHwnd())))  
		return ::GetDesktopWindow();
	return pWnd->GetSafeHwnd();
}
int CMessage::msgYesNo(LPCTSTR lpszText,LPCTSTR lpszTitle,CWnd *pWnd)
{
    int result = MessageBox( GetWindow(pWnd), lpszText , lpszTitle ,
               MB_YESNO|MB_ICONEXCLAMATION|MB_DEFBUTTON2);

	if (result==IDYES) {
		LPCTSTR  lpszConfirm = _T("Are you sure ?");
		int result = MessageBox( GetWindow(pWnd), 
				lpszConfirm , lpszTitle ,
				MB_YESNO|MB_ICONSTOP|MB_DEFBUTTON2);
	}
	return ((result==IDYES) ? (1) : (0));
}

void CMessage::msg(LPCTSTR lpszText,LPCTSTR lpszTitle,CWnd *pWnd)
{
	::MessageBox( GetWindow(pWnd), lpszText , lpszTitle , MB_OK);
}

void CMessage::Error(LPCTSTR lpszText,LPCTSTR lpszTitle)
{
	::MessageBox( GetWindow(), lpszText ,
			lpszTitle , MB_OK|MB_ICONEXCLAMATION);
}

void CMessage::Error(DWORD errCode, CWnd *pWnd)//system error message
{
	LPVOID lpMsgBuf;
	FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS ,
		NULL,  errCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL );

	::MessageBox( GetWindow(pWnd), (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
	::LocalFree(lpMsgBuf);
}

// positions start with 1 to ...
// UNICODE not checked yet
BOOL CMessage::FormatElement( LPCTSTR lpszBuffer,int iPosition , LPCTSTR lpszFormatSpecifier , LPVOID lpData)
{
	ASSERT(lpszBuffer!=NULL);
	ASSERT(iPosition>0);
	ASSERT(lpData!=NULL);

	CString strBuff = lpszBuffer;
	strBuff.TrimLeft(_T(' '));
	strBuff.TrimRight(_T(' '));
	TCHAR *p = (TCHAR*)(LPCTSTR)strBuff;
	int iCurrentPos = 1;

	while ((iCurrentPos<iPosition) && (p)) { //moving to place
		if (*p == _T(' ')) iCurrentPos++;
		p++;
	}

	if (!::lstrcmp( lpszFormatSpecifier , _T("%d"))) {
		(*(int*)lpData) = _ttoi(p);
		return TRUE;
	}
	if (!::lstrcmp( lpszFormatSpecifier , _T("%u"))) {
		(*(UINT*)lpData) = _ttol(p);
		return TRUE;
	}
	if (!::lstrcmp( lpszFormatSpecifier , _T("%c"))) {
		(*(TCHAR*)lpData) = (TCHAR) _ttoi(p);
		return TRUE;
	}
	if (!::lstrcmp( lpszFormatSpecifier , _T("%f"))) {
		(*(float*)lpData) = (float) atof(p);
		return TRUE;
	}
	if (!::lstrcmp( lpszFormatSpecifier , _T("%x"))) {
		(*(int*)lpData) = _ttoi(p);
		return TRUE;
	}
	if (!::lstrcmp( lpszFormatSpecifier , _T("%s"))) {
		(*(CString*)lpData) = (LPCTSTR) p;
		int iFind = (*(CString*)lpData).Find( _T(' '));
		if (iFind != -1)
			(*(CString*)lpData) = (*(CString*)lpData).Left(iFind); 
		//removing characters after space
		return TRUE;
	}

	return FALSE;
}

BOOL CMessage::FormatElements( LPCTSTR lpszBuffer, LPCTSTR lpszFormatSpecifier,
			LPVOID lpData1, LPVOID lpData2, LPVOID lpData3, LPVOID lpData4, LPVOID lpData5, 
			LPVOID lpData6, LPVOID lpData7, LPVOID lpData8, LPVOID lpData9, LPVOID lpData10)
{
	BOOL bAccomulatedResult = TRUE ,bResult = TRUE;
	CString strFullFormats = lpszFormatSpecifier;
	strFullFormats.TrimLeft(_T(' '));
	strFullFormats.TrimRight(_T(' '));
	
	TCHAR lpszFormatSpec[3];
	TCHAR *pString = (TCHAR*)(LPCTSTR)strFullFormats;
	int iLength = strFullFormats.GetLength();

	for (int i = 0 ,iCount = 0 ; i< min(10,iLength) ; i++) { //10 values in buffer
		if (strFullFormats.GetAt(i) == _T('%')) {
			::lstrcpyn( lpszFormatSpec, (LPCTSTR)(pString+i),3);
			lpszFormatSpec[2] = 0;//not needed (done by lstrcpyn) , just to be sure
			
			iCount++;
			switch (iCount)
			{
			case 1: if (lpData1)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData1);
				break;
			case 2: if (lpData2)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData2);
				break;
			case 3: if (lpData3)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData3);
				break;
			case 4: if (lpData4)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData4);
				break;
			case 5: if (lpData5)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData5);
				break;
			case 6: if (lpData6)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData6);
				break;
			case 7: if (lpData7)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData7);
				break;
			case 8: if (lpData8)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData8);
				break;
			case 9: if (lpData9)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData9);
				break;
			case 10: if (lpData10)
						bResult = FormatElement( lpszBuffer, iCount , lpszFormatSpec , lpData10);
				break;
			}
			if ((!bResult) && (bAccomulatedResult))
				bAccomulatedResult = bResult;
		}//end found %...
	}//end for

	return bAccomulatedResult;
}


