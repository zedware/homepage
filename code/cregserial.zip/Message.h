/*  This file was written by Amir Israeli , July 2000   Email: israelaq@walla.co.il  
No warranty of any kind . Dont remove this header . Thanks.
*/
// Message.h: interface for the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESSAGE_H__6C963F0F_503D_11D4_B8C4_893BB50FF25B__INCLUDED_)
#define AFX_MESSAGE_H__6C963F0F_503D_11D4_B8C4_893BB50FF25B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMessage  
{
public:
	CMessage();
	virtual ~CMessage();
public:
	static int msgYesNo(LPCTSTR lpszText,LPCTSTR lpszTitle = NULL,CWnd *pWnd = NULL);
	static void msg(LPCTSTR lpszText,LPCTSTR lpszTitle = NULL,CWnd *pWnd = NULL);
	static void Error(LPCTSTR lpszText,LPCTSTR lpszTitle = NULL);
	
	//system error message : DWORD from ::GetLastError()
	static void Error(DWORD errCode , CWnd *pWnd = NULL);

protected:
	static HWND GetWindow(CWnd *pWnd = NULL);

public:
	static BOOL FormatElement( LPCTSTR lpszBuffer, int iPosition , LPCTSTR lpszFormatSpecifier, LPVOID lpData);
	static BOOL FormatElements( LPCTSTR lpszBuffer, LPCTSTR lpszFormatSpecifier, 
			LPVOID lpData1 = NULL, LPVOID lpData2 = NULL, LPVOID lpData3 = NULL, LPVOID lpData4 = NULL, LPVOID lpData5 = NULL, 
			LPVOID lpData6 = NULL, LPVOID lpData7 = NULL, LPVOID lpData8 = NULL, LPVOID lpData9 = NULL, LPVOID lpData10 = NULL);

};

#endif // !defined(AFX_MESSAGE_H__6C963F0F_503D_11D4_B8C4_893BB50FF25B__INCLUDED_)
