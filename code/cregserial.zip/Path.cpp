// Path.cpp: implementation of the CPath class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Path.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPath::CPath()
{
}
CPath::~CPath()
{
}

//////// general paths functions 
void CPath::Trim( CString &strRegPath, TCHAR ch)
{
	strRegPath.TrimLeft(ch);
	strRegPath.TrimRight(ch);
}
BOOL CPath::AppendPath(CString &strRegTarget,LPCTSTR lpszRegSrc)
{
    Trim(strRegTarget);
    CString src = lpszRegSrc;
	Trim(src);
	strRegTarget += _T('\\');
	strRegTarget += src;
	Trim(strRegTarget);

#ifdef _DEBUG
	CMessage::msg(strRegTarget);
#endif
	
	return TRUE;
}
BOOL CPath::IsEqual( const CString strSrc1, const CString strSrc2, BOOL bNoCase)
{
	return (bNoCase) ?
		(strSrc1.CompareNoCase( strSrc2) == 0) :
		(strSrc1.Compare( strSrc2) == 0 ) ;
}
////////////////////////////////////////////////////////////////////
///////////////// (look in ".h")
BOOL CPath::FormulatePath( CString &strRegPath, HKEY &hKey)
{
	CString strPath = strRegPath;
	Trim(strPath);

	int place = strPath.Find(_T('\\'));
	if (place==-1) 
		place = strPath.GetLength(); //only includes a root item
	CString strRoot = strPath.Left(place);
	if (!StringRoot2key( strRoot, hKey))	{

#ifdef _DEBUG
		CMessage::Error("contains no such root");
#endif

		return FALSE;
	}

	strRegPath = strPath.Mid(place);
	Trim(strRegPath);
	return TRUE;
}

////////////////////////////////////////////////////////
///////// Conversion between strings that represent root-keys
//to root keys and vice-versa. (protected functions)
BOOL CPath::RootKey2String( CString &strRegSrc,HKEY &hKey)
{
	if (hKey == HKEY_CLASSES_ROOT) {
		strRegSrc = _T("HKEY_CLASSES_ROOT");
		return TRUE;
	}	
	else if (hKey == HKEY_CURRENT_CONFIG) {
		strRegSrc = _T("HKEY_CURRENT_CONFIG");
		return TRUE;
	}	
	else if (hKey == HKEY_CURRENT_USER)	{
		strRegSrc = _T("HKEY_CURRENT_USER");
		return TRUE;
	}
	else if (hKey == HKEY_LOCAL_MACHINE) {
		strRegSrc = _T("HKEY_LOCAL_MACHINE");
		return TRUE;
	}
	else if (hKey == HKEY_USERS) {
		strRegSrc = _T("HKEY_USERS");
		return TRUE;
	}
	else if (hKey == HKEY_DYN_DATA)	{
		strRegSrc = _T("HKEY_DYN_DATA");
		return TRUE;
	}
	else if (hKey == HKEY_PERFORMANCE_DATA) {
		strRegSrc = _T("HKEY_PERFORMANCE_DATA");
		return TRUE;
	}
	return FALSE;
}
BOOL CPath::StringRoot2key( const CString strRegPath, HKEY &hKey)
{
	CString strRoot;
	CString strPath = strRegPath;
	Trim(strPath);
	GetLevel( 0, (LPCTSTR)strPath, strRoot);
	if (strRoot.IsEmpty())	return FALSE;

	if ((IsEqual( strRoot, _T("HKEY_CLASSES_ROOT"))) || (IsEqual( strRoot, _T("HKCR")))) {
		hKey = HKEY_CLASSES_ROOT;
		return TRUE;
	}
	if ((IsEqual( strRoot, _T("HKEY_CURRENT_CONFIG"))) || (IsEqual( strRoot, _T("HKCC")))) {
		hKey =  HKEY_CURRENT_CONFIG;
		return TRUE;
	}
	if ((IsEqual( strRoot, _T("HKEY_CURRENT_USER"))) || (IsEqual( strRoot, _T("HKCU")))) {
		hKey = HKEY_CURRENT_USER;
		return TRUE;
	}
	if ((IsEqual( strRoot, _T("HKEY_LOCAL_MACHINE"))) || (IsEqual( strRoot, _T("HKLM")))) {
		hKey = HKEY_LOCAL_MACHINE;
		return TRUE;
	}
	if ((IsEqual( strRoot, _T("HKEY_USERS"))) || (IsEqual( strRoot, _T("HKU")))) {
		hKey = HKEY_USERS;
		return TRUE;
	}
	if ((IsEqual( strRoot, _T("HKEY_DYN_DATA"))) || (IsEqual( strRoot, _T("HKDD")))) {
		hKey = HKEY_DYN_DATA;
		return TRUE;
	}
	if ((IsEqual( strRoot, _T("HKEY_PERFORMANCE_DATA"))) || (IsEqual( strRoot, _T("HKPD")))) {
		hKey = HKEY_PERFORMANCE_DATA;
		return TRUE;
	}
	return FALSE;
}

///////////////////////////////////////////////////////////
////////////// Level functions
int CPath::CountLevels( LPCTSTR lpszRegPath)
{
	CString sPath = lpszRegPath;
	Trim(sPath);
	int iTotal = sPath.GetLength();
	if (!iTotal)  return 0;

	for (int iCount=1 , i=0 ; i<iTotal ; i++)
		if ( sPath.GetAt(i) == _T('\\'))  iCount++;
	return iCount;
}
BOOL CPath::GetLevel(int iLevel, LPCTSTR lpszRegPath, CString &strRegOut)
{
	CString sPath = lpszRegPath;
	Trim(sPath);
	int iCount = CountLevels( (LPCTSTR) sPath );
	if (!iCount)  return FALSE;//no levels in name
	if ((iLevel<0) || (iLevel>=iCount)) //out of boundary
		return FALSE;//no such level

	for ( int i=0 , tmp=0 ; tmp < iLevel ; i++)
		if (sPath[i] == _T('\\'))  tmp++;

	sPath = sPath.Mid(i);
	i = sPath.Find(_T('\\'));
	if (i>=0)	sPath = sPath.Left(i);
	
	strRegOut = sPath;
	return TRUE;
}
BOOL CPath::GetLastLevel( LPCTSTR lpszRegPath , CString &strRegOut)
{
	CString path = lpszRegPath;
	Trim(path);
	int iLevels = CountLevels( (LPCTSTR) path);
	if (!iLevels)  return FALSE;
	return GetLevel( iLevels-1, path, strRegOut);
}
BOOL CPath::LevelInPath( LPCTSTR lpszRegPath , CString &strWantedKey)
{
	CString path = lpszRegPath;
	Trim(path);
	int iLevels = CountLevels( (LPCTSTR) path);
	if (!iLevels)  return FALSE;

	CString str;
	for (int i=0 ; i<iLevels ; i++)
		if ((GetLevel( i, (LPCTSTR) path, str)) && (IsEqual(strWantedKey,str)))
			return TRUE;
	return FALSE;
}
BOOL CPath::GetLevelBeforeLevel( LPCTSTR lpszRegPath , LPCTSTR lpszBeforeLevel, CString &strOut, BOOL bGiveRoot)
{
	CString path = lpszRegPath;
	Trim(path);
	int iLevels = CountLevels( (LPCTSTR) path);
	if (iLevels<2)  return FALSE;//1 level only so theres non before
	
	CString str;
	for (int i=1 ; i<iLevels ; i++)
		if ((GetLevel( i, (LPCTSTR) path, str)) && (IsEqual(str,lpszBeforeLevel))) {
			if ((((i==1) && (bGiveRoot)) || (i>1)) && (GetLevel( i-1, (LPCTSTR) path, str))) {
				strOut = str;
				return TRUE;
			}
		}
	return FALSE;
}
BOOL CPath::GetLevelAfterLevel( LPCTSTR lpszRegPath , LPCTSTR lpszAfterLevel, CString &strOut)
{
	CString path = lpszRegPath ;
	Trim(path);
	int iLevels = CountLevels(path);
	if (iLevels<2)  return FALSE;//no levels after level

	CString str;
	for (int i=0 ; i<iLevels-1 ; i++)
		if ((GetLevel( i,(LPCTSTR) path, str)) && (IsEqual(str,lpszAfterLevel))) {
			if (GetLevel( i+1, (LPCTSTR) path, str)) {
				strOut = str;
				return TRUE;
			}
		}
	return FALSE;
}
BOOL CPath::RemoveLastItem(CString &strRegPath)
{
	Trim(strRegPath);
	int place = strRegPath.ReverseFind(_T('\\'));
	if (place==-1)
		return TRUE; //the same string returned if only 1 level
	else	strRegPath = strRegPath.Left(place);
	Trim(strRegPath);
	return TRUE;
}
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////





