// Path.h: interface for the CPath class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PATH_H__5D6C5786_6F82_11D4_B8C4_855DBE99815C__INCLUDED_)
#define AFX_PATH_H__5D6C5786_6F82_11D4_B8C4_855DBE99815C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Message.h"

class CPath  
{
public:
	CPath();
	virtual ~CPath();

	//Trims a character off a string (both sides)
	void Trim( CString &strRegPath, TCHAR ch = _T('\\'));
	BOOL AppendPath( CString &strRegTarget, LPCTSTR strRegSrc);

	/////// Level functions
	int CountLevels( LPCTSTR lpszRegPath);
	BOOL GetLevel( int iLevel, LPCTSTR lpszRegPath, CString &strRegOut);
	BOOL GetLastLevel( LPCTSTR lpszRegPath, CString &strRegOut);
	BOOL LevelInPath( LPCTSTR lpszRegPath, CString &strWantedKey);
	BOOL GetLevelBeforeLevel( LPCTSTR lpszRegPath , LPCTSTR lpszBeforeLevel,CString &strOut,BOOL bGiveRoot=FALSE);
	BOOL GetLevelAfterLevel( LPCTSTR lpszRegPath, LPCTSTR lpszAfterLevel,CString &strOut);
	BOOL RemoveLastItem( CString &strRegPath);

	void msg( LPCTSTR lpszText = NULL , LPCTSTR lpszTitle = NULL ) {
		CMessage::msg( lpszText , lpszTitle);
	}
	
	BOOL FormulatePath( CString &strRegPath, HKEY &hKey);
	BOOL IsEqual( const CString strSrc1, const CString strSrc2, BOOL bNoCase = TRUE);
	
protected:
	BOOL RootKey2String( CString &strRegSrc, HKEY &hKey);
	BOOL StringRoot2key( const CString strRegPath, HKEY &hKey);


};

#endif // !defined(AFX_PATH_H__5D6C5786_6F82_11D4_B8C4_855DBE99815C__INCLUDED_)
