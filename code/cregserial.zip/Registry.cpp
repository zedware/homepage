// Registry.cpp: implementation of the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Registry.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRegistry::CRegistry()
{
	bAutoFlush = FALSE;
}

CRegistry::~CRegistry()
{

}

//returns the previous state of flush

BOOL CRegistry::SetFlush( BOOL bFlush)
{
	BOOL bPrev = bAutoFlush;
	bAutoFlush = bFlush;
	return bPrev;
}

////////////////////////////////////////////////////////
///////// Enumeration functions

BOOL CRegistry::Enum( HKEY &hRootKey, LPCTSTR lpszRegPath, CStringArray *pArrKeyNames, CStringArray *pArrClassNames, BOOL bFullPath)
{
	HKEY hNewKey;
	if (!Open( hRootKey, lpszRegPath, hNewKey))   
		return FALSE;

	TCHAR strKeyName[MAX_PATH*2],strClassName[MAX_PATH*2];
	DWORD dwNameSize=sizeof(strKeyName),dwClassSize=sizeof(strClassName);
    DWORD i=0;
	
	for (LONG result = ERROR_SUCCESS ; 
		((result==ERROR_SUCCESS) && (result!=ERROR_NO_MORE_ITEMS)) ;
		  i++)
	{
		dwNameSize = sizeof(strKeyName);
		dwClassSize = sizeof(strClassName);

        result = ::RegEnumKeyEx(hNewKey, i,strKeyName, &dwNameSize,NULL,strClassName, &dwClassSize,NULL);
        if (result == (DWORD)ERROR_SUCCESS) //suceeded getting name
        {
			pArrKeyNames->Add((LPCTSTR)strKeyName);
			if (pArrClassNames)  pArrClassNames->Add((LPCTSTR)strClassName);
		}
	}//end "for"

	Close(hNewKey);
	return TRUE;
}

BOOL CRegistry::Enum( LPCTSTR lpszRegPath, CStringArray *pArrKeyNames,CStringArray *pArrClassNames,BOOL bFullPath)
{
	CString str = lpszRegPath;
	HKEY hRootKey;
	if (!GetPathObj().FormulatePath( str, hRootKey))  
		return FALSE;
	return Enum( hRootKey, str, pArrKeyNames, pArrClassNames, bFullPath);
}

///////// Open Keys functions
///////////////////

BOOL CRegistry::Open( LPCTSTR lpszRegPath, HKEY &hNewKey, REGSAM samDesired)
{
	HKEY hRootKey;
	CString strPath = lpszRegPath;
	if (!GetPathObj().FormulatePath( strPath, hRootKey))
		return FALSE;
	return Open( hRootKey, strPath, hNewKey, samDesired);	
}


BOOL CRegistry::Open( HKEY &hKey, LPCTSTR lpszRegPath, HKEY &hNewKey, REGSAM samDesired)
{
	//hNewKey=NULL;
	LONG lResult = ERROR_SUCCESS;
	
	if (::lstrlen(lpszRegPath)>0) //not in root key (need to open)
		  lResult = ::RegOpenKeyEx( hKey, lpszRegPath, 0, samDesired, &hNewKey);
	else  hNewKey = hKey;//we are in root key dont need to open
	return (lResult==ERROR_SUCCESS);
}


BOOL CRegistry::Close(HKEY &hKey)
{
	LONG lResult=ERROR_SUCCESS;
	if (bAutoFlush) Flush(hKey);//flushing this key

	if (!IsRoot(hKey)) //closing only is this is not the root
		lResult = RegCloseKey(hKey);
	return (lResult == ERROR_SUCCESS);
}

////////////////////////////////////////////////////////
///////// Flush function : immediate write

BOOL CRegistry::Flush(HKEY &hKey)
{
	LONG lResult = RegFlushKey(hKey);
	return (lResult == ERROR_SUCCESS);
}
////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
/////// IsExistValue Functions

BOOL CRegistry::IsExistValue( LPCTSTR lpszKeyName, LPCTSTR lpszValue)
{
	if (!lpszKeyName)  return FALSE;
	CString strRegPath = lpszKeyName;
	GetPathObj().Trim(strRegPath);
	HKEY hNewKey;
	if (Open( strRegPath, hNewKey, KEY_QUERY_VALUE )) {
		BOOL bFound  = IsExistValue( hNewKey, lpszValue);
		Close(hNewKey);
		return bFound;
	}
	return FALSE;
}

BOOL CRegistry::IsExistValue( HKEY &hKey, LPCTSTR lpszValue)
{
	LONG result = ::RegQueryValueEx( hKey, lpszValue, 0,
						NULL, NULL, NULL);
	return (result == ERROR_SUCCESS);
}

/////////////////////////////////////////////////////////
/////// Functions to get count of keys

BOOL CRegistry::IsKeyHasSubKeys( LPCTSTR lpszRegPath)
{
	return (GetSubKeyCount(lpszRegPath) > 0);
}

BOOL CRegistry::IsKeyHasSubKeys( HKEY &hRegKey)
{	
	return (GetSubKeyCount(hRegKey) > 0);
}

int CRegistry::GetSubKeyCount( LPCTSTR lpszRegPath)
{
	CString strPath = lpszRegPath;
	HKEY hRootKey,hNewKey;
	if (!GetPathObj().FormulatePath( strPath, hRootKey))  return -1;
	if (!Open( hRootKey, strPath, hNewKey))  return -1;
	
	int iCount = GetSubKeyCount(hNewKey);
	Close(hNewKey);
	return iCount;
}

int CRegistry::GetSubKeyCount(HKEY &hKey)
{
	DWORD dwSubKeys = 0;
	if (::RegQueryInfoKey( hKey, NULL, NULL, NULL,
			   &dwSubKeys, NULL, NULL, NULL, NULL,
			   NULL, NULL, NULL) == ERROR_SUCCESS)
			return (int)dwSubKeys;
	return -1;
}

////////////////////////////////////////////////////////
///////  IsRoot functions

BOOL CRegistry::IsRoot( HKEY &hKey, LPCTSTR lpszRegPath)
{
	if (!(( hKey == HKEY_CLASSES_ROOT)  || 
		  ( hKey == HKEY_CURRENT_CONFIG) || 
		  ( hKey == HKEY_CURRENT_USER) ||
		  ( hKey == HKEY_LOCAL_MACHINE) || 
		  ( hKey == HKEY_PERFORMANCE_DATA) || 
		  ( hKey == HKEY_USERS) ||
		  ( hKey == HKEY_DYN_DATA)))   return FALSE;//not root

	if ((!lpszRegPath) || (::lstrlen(lpszRegPath) == 0))
		return TRUE; //pointer is NULL : this is root
	return FALSE;
}

BOOL CRegistry::IsRoot( LPCTSTR lpszRegPath)
{
	CString str = lpszRegPath;
	GetPathObj().Trim(str);
	if (GetPathObj().IsEqual( str, _T("HKEY_CLASSES_ROOT")))
		return TRUE;
	if (GetPathObj().IsEqual( str , _T("HKEY_CURRENT_CONFIG")))
		return TRUE;
	if (GetPathObj().IsEqual( str , _T("HKEY_CURRENT_USER")))
		return TRUE;
	if (GetPathObj().IsEqual( str , _T("HKEY_LOCAL_MACHINE")))
		return TRUE;
	if (GetPathObj().IsEqual( str , _T("HKEY_USERS")))
		return TRUE;
	if (GetPathObj().IsEqual( str , _T("HKEY_DYN_DATA")))
		return TRUE;
	if (GetPathObj().IsEqual( str , _T("HKEY_PERFORMANCE_DATA")))
		return TRUE;
	return FALSE;
}

/////////////////////////////////////////////////////////////
////////// IsExistKey functions
//checks whether a key exists in registry ...

BOOL CRegistry::IsExistKey( LPCTSTR lpszRegPath)
{
	CString path = lpszRegPath;
	GetPathObj().Trim(path);
	HKEY hNewKey;
	if (Open(path,hNewKey)){
		Close(hNewKey);
		return TRUE;
	}
	return FALSE;
}

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////////// Functions to Delete Keys and Values ....

//if on windows NT : (unicode systems) indlude atl for recursive
//deletion of registry keys on with "CRegKey"
//(no need to reinvent the wheel)
#ifdef UNICODE
	#include <atlbase.h>
#endif


BOOL CRegistry::DeleteKey( LPCTSTR lpszRegPath )
{
	CString path = lpszRegPath ;
	HKEY hRootKey;
	if (!GetPathObj().FormulatePath( path, hRootKey))  return FALSE;

#ifdef UNICODE
	CRegKey atlRegKey;
	atlRegKey.Attach(hRootKey);
	return (atlRegKey.RecurseDeleteKey((LPCTSTR)path)==ERROR_SUCCESS);
#else
	return DeleteKey( hRootKey, path);
#endif
}


BOOL CRegistry::DeleteKey( HKEY &hKey, LPCTSTR lpszRegPath) 
{
	if (::RegDeleteKey( hKey, lpszRegPath ) == ERROR_SUCCESS)
		return TRUE;
	return FALSE;
}

BOOL CRegistry::DeleteValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName) 
{
	CString path = lpszRegPath ;
	HKEY hRootKey,hNewKey;
	if (!GetPathObj().FormulatePath( path, hRootKey))  return FALSE;
	
	if (!Open(hRootKey, path, hNewKey,KEY_SET_VALUE ))
		return FALSE;
	
	BOOL bResult = DeleteValue( hNewKey, lpszValueName);

	Close(hNewKey);
	return bResult;
}

BOOL CRegistry::DeleteValue(HKEY &hKey, LPCTSTR lpszValueName)
{
	if (::RegDeleteValue( hKey, lpszValueName )== ERROR_SUCCESS)
		return TRUE;
	return FALSE;
}


///////////////////////////////////////////////////////////
////////// GetValue  functions
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CString *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)(LPCTSTR)pData, 0, REG_SZ);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, DWORD *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(DWORD), REG_DWORD);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, int *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(int), REG_BINARY);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, float *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(float), REG_BINARY);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CPoint *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CPoint), REG_BINARY);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CRect *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CRect), REG_BINARY);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CTime *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CTime), REG_BINARY);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CSize *pData)
{
	return GetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CSize), REG_BINARY);
}
BOOL CRegistry::GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPBYTE pData, size_t size, DWORD dwType)
{
	CString strRegPath = lpszRegPath;
	HKEY hRootKey,hNewKey;
	if (!GetPathObj().FormulatePath( strRegPath, hRootKey)) 
		return FALSE;
	if (!Open( hRootKey, strRegPath, hNewKey))  return FALSE;

	DWORD cbData = 0;
	// Get the length of the data 
	DWORD dwGotType;
	LONG  result = ::RegQueryValueEx( hNewKey, lpszValueName,
				NULL, &dwGotType, NULL , &cbData);
	
	if (result != ERROR_SUCCESS)
		return FALSE;
	if (dwGotType != dwType) //type mismatch : holds something else
		return FALSE;
	
	LPBYTE pBuffer = new BYTE[cbData+1];
	if (!pBuffer)  return FALSE;
	memset( pBuffer, 0, cbData+1);

	//Get the data
	result = ::RegQueryValueEx( hNewKey, lpszValueName, NULL, 
			&dwGotType, pBuffer, &cbData);
	
	if (result == ERROR_SUCCESS) {
		if (dwType == REG_SZ) //pData is actually a CString object
			(*(CString*)pData) = (LPCTSTR)pBuffer;
		else
			::CopyMemory( pData, pBuffer, min(cbData,size) );
	}

	delete [] pBuffer;
	Close(hNewKey);	
	return (result == ERROR_SUCCESS);
}

///////////////////////////////////////////////////////////
/////////// Functions to create keys
BOOL CRegistry::CreateKey( LPCTSTR lpszRegPath)
{
	CString path = lpszRegPath ;
	HKEY hRootKey,hNewKey;
	if (!GetPathObj().FormulatePath( path, hRootKey))  return FALSE;

	BOOL bResult = CreateKey( hRootKey, path);
	Close(hNewKey);
	return bResult;
}
BOOL CRegistry::CreateKey( HKEY &hKey, LPCTSTR lpszRegPath)
{
	HKEY hKeyResult;
	if (!lpszRegPath)  return FALSE;
	REGSAM regSam = KEY_CREATE_SUB_KEY|KEY_ENUMERATE_SUB_KEYS;
	LONG result = ::RegCreateKeyEx( hKey, lpszRegPath , 0 ,
							NULL , REG_OPTION_NON_VOLATILE , regSam ,
							NULL , &hKeyResult ,
							NULL);
	Close(hKeyResult);
	return (result == ERROR_SUCCESS);
}
////////////////////////////////////////////////////////////////
//////// Create Value functions ...
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPCTSTR pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, ::lstrlen(pData), REG_SZ);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, DWORD *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(DWORD), REG_DWORD);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, int *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(int), REG_BINARY);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, float *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(float), REG_BINARY);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CPoint *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CPoint), REG_BINARY);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CRect *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CRect), REG_BINARY);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CSize *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CSize), REG_BINARY);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CTime *pData)
{
	return SetValue( lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CTime), REG_BINARY);
}
BOOL CRegistry::CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPBYTE pData, size_t size, DWORD dwType)
{
	return SetValue( lpszRegPath, lpszValueName, pData, size, REG_BINARY);
}
///////////////////////////////////////////////////////////
//////////////  Functions to set values
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPCTSTR pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, ::lstrlen(pData), REG_SZ);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, DWORD *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(DWORD), REG_DWORD);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, int *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(int), REG_BINARY);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, float *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(float), REG_BINARY);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CPoint *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CPoint), REG_BINARY);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CRect *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CRect), REG_BINARY);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CSize *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CSize), REG_BINARY);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CTime *pData)
{
	return SetValue(lpszRegPath, lpszValueName, (LPBYTE)pData, sizeof(CTime), REG_BINARY);
}
BOOL CRegistry::SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPBYTE pData, size_t size, DWORD dwType)
{
	CString path = lpszRegPath ;
	HKEY hRootKey,hNewKey;
	if (!GetPathObj().FormulatePath( path, hRootKey))  return FALSE;
	
	if (!Open(hRootKey, path, hNewKey, KEY_WRITE|KEY_READ))
		return FALSE;

	LONG result = ::RegSetValueEx( hNewKey, lpszValueName, 0,
					 dwType, (const LPBYTE)pData, (DWORD)size);

	Close(hNewKey);
	return (result==ERROR_SUCCESS);
}





