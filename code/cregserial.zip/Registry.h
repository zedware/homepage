// TRegistry.h: interface for the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REGISTRY_H__5D6C5784_6F82_11D4_B8C4_855DBE99815C__INCLUDED_)
#define AFX_REGISTRY_H__5D6C5784_6F82_11D4_B8C4_855DBE99815C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Message.h"
#include "Path.h"
#include "Message.h"


class CRegistry  
{
public:
	CRegistry();
	virtual ~CRegistry();

	CPath& GetPathObj() { return m_path; }
	BOOL GetFlush(){ return bAutoFlush; }
	BOOL SetFlush(BOOL bFlush = FALSE); // returns the previous state of flush

	void msg(LPCTSTR lpszText = NULL, LPCTSTR lpszTitle = NULL) {
		CMessage::msg(lpszText, lpszTitle);
	}

	/// Open Keys functions
	BOOL Open( LPCTSTR lpszRegPath,HKEY &hNewKey, REGSAM samDesired = KEY_READ);

	/// IsExist...  functions
	BOOL IsExistKey( LPCTSTR lpszRegPath);
	BOOL IsExistValue( LPCTSTR lpszKeyName, LPCTSTR lpszValue);

	BOOL IsKeyHasSubKeys( LPCTSTR lpszRegPath);
	int  GetSubKeyCount( LPCTSTR lpszRegPath);
	
	/// Enumeration functions
	int Enum( LPCTSTR lpszRegPath, CStringArray *pArrKeyNames, CStringArray *pArrClassNames = NULL, BOOL bFullPath = FALSE);

	/// Functions to manipulate keys
	BOOL CreateKey( LPCTSTR lpszRegPath);
	BOOL DeleteKey( LPCTSTR lpszRegPath);
	BOOL DeleteValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName);

	/// Functions to get a value (overloaded)
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CString *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, DWORD *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, int *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, float *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CPoint *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CRect *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CTime *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CSize *pData);
	BOOL GetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPBYTE pData = NULL, size_t size = 0, DWORD dwType = REG_BINARY);

	/// Functions to create a value (call SetValue) (overloaded)
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPCTSTR pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, DWORD *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, int *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, float *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CPoint *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CRect *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CSize *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CTime *pData);
	BOOL CreateValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPBYTE pData = NULL, size_t size = 0, DWORD dwType = REG_BINARY);

	//Functions to set the value (overloaded)
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPCTSTR pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, DWORD *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, int *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, float *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CPoint *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CRect *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CSize *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, CTime *pData);
	BOOL SetValue( LPCTSTR lpszRegPath, LPCTSTR lpszValueName, LPBYTE pData = NULL, size_t size = 0, DWORD dwType = REG_BINARY);

protected:	
	
	/// Open Keys functions
	BOOL Open( HKEY &hKey, LPCTSTR lpszRegPath, HKEY &hNewKey, REGSAM samDesired = KEY_READ);
	BOOL Close(HKEY &hKey);
	
	/// Enumeration functions
	int Enum( HKEY &hRootKey, LPCTSTR lpszRegPath, CStringArray *pArrKeyNames, CStringArray *pArrClassNames = NULL, BOOL bFullPath = FALSE);

	BOOL IsExistValue( HKEY &hKey, LPCTSTR lpszValue);

	BOOL IsKeyHasSubKeys( HKEY &hKey);
	int  GetSubKeyCount( HKEY &hKey);

	BOOL CreateKey( HKEY &hKey, LPCTSTR lpszRegPath);
	BOOL DeleteKey(HKEY &hKey,LPCTSTR lpszRegPath);
	BOOL DeleteValue(HKEY &hKey, LPCTSTR lpszValueName);

	///  IsRoot functions
	BOOL IsRoot( LPCTSTR lpszRegPath);
	BOOL IsRoot( HKEY &hKey, LPCTSTR lpszRegPath = NULL);

	//// Flush function : immediate write
	BOOL Flush(HKEY &hKey);

private:
	CPath  m_path;//use with paths

	BOOL bAutoFlush; // determines whether to flush keys
	// whenever we save it (unrecommended:takes many resources)

};

#endif // !defined(AFX_REGISTRY_H__5D6C5784_6F82_11D4_B8C4_855DBE99815C__INCLUDED_)
