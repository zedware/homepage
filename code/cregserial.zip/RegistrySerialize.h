#if !defined(AFX_REGISTRYSERIALIZE_H__A5E77AA7_705C_11D4_B8C4_9439EECEC459__INCLUDED_)
#define AFX_REGISTRYSERIALIZE_H__A5E77AA7_705C_11D4_B8C4_9439EECEC459__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RegistrySerialize.h : header file
//

#include <afxtempl.h>
#include "Registry.h"

///////////////////////////////////////////////////////////////////
enum REGDATA { REGSTRING=1, REGDWORD, REGINT, REGPBYTE,
			REGFLOAT, REGPOINT, REGSIZE,
			REGTIME, REGRECT, REGBYTE , REGEMPTY=0 };

class CSerializedKeyPath;

class CSerializedValue : public CObject 
{
public:
	CSerializedValue();
	CSerializedValue ( CSerializedKeyPath* , CRegistry* );
	virtual ~CSerializedValue();
	virtual void Serialize(CArchive &ar);

	BOOL SetInfo( LPCTSTR lpszValueName, REGDATA iType , BOOL bDeleteOnUnInstall = TRUE);
	CString GetValueName() { return strValueName; }
	REGDATA GetType() { return iDataType; }
	BOOL GetDelete() { return bDeleteOnUnInstall; }

protected:
	CString SetValueName( LPCTSTR lpszValueName = NULL ) {
		return strValueName = lpszValueName;
	}
	REGDATA SetType(REGDATA data = REGEMPTY ) {
		return iDataType = data;
	}
	BOOL SetDelete(BOOL bDelete = TRUE) {
		return bDeleteOnUnInstall = bDelete;
	}

////// Install , UnInstall , Load , Save values
public:
	BOOL UnInstall();
	BOOL Install();

	BOOL Persist( DWORD *dwDest , BOOL bLoading = TRUE );
	BOOL Persist( CString *pstrDest , BOOL bLoading = TRUE );
	BOOL Persist( int *iDest , BOOL bLoading = TRUE );
	BOOL Persist( float *pfDest , BOOL bLoading = TRUE );
	BOOL Persist( CRect *pRect , BOOL bLoading = TRUE );
	BOOL Persist( CPoint *pPoint , BOOL bLoading = TRUE );
	BOOL Persist( CSize *pSize , BOOL bLoading = TRUE );
	BOOL Persist( CTime *ptDest , BOOL bLoading = TRUE );
	BOOL Persist( LPBYTE *lpByte,DWORD cbBuffLen , BOOL bLoading = TRUE );

////////////////////////////////
protected:
	DECLARE_SERIAL(CSerializedValue)
	
	REGDATA iDataType;
	CString strValueName;
	BOOL bDeleteOnUnInstall;

	CRegistry *pReg;
	CSerializedKeyPath *pathOwner;
};

//structures are based on array templates , sequential search is bad
//therefore modifying to maps is a great idea (your job)
//used in every path key
typedef CArray<CSerializedValue* ,CSerializedValue*&> arrValues;
//typedef CTypedPtrArray<

class CSerializedKeyPath : public CObject
{
public:
	CSerializedKeyPath();
	CSerializedKeyPath( CRegistry *p);

#ifdef _DEBUG //look at CRegistrySerialize::Info
	void Info();
#endif

	virtual ~CSerializedKeyPath();
	virtual void Serialize(CArchive &ar);
	BOOL InsertCSerializedValue(CSerializedValue *pNewValue);

	BOOL InsertValue( LPCTSTR lpszValueName ,
		 REGDATA iDataType , BOOL bDeleteOnUnInstall);

	////// Install , UnInstall , Load , Save values
public:
	CString GetPath() { return strPath; }
	void SetPath( LPCTSTR lpszPath) {
		strPath = lpszPath;
	}
	
	void SetDelete( BOOL bDelete = TRUE) { bDeleteOnUnInstall = bDelete ; }
	void SetRegistryObject( CRegistry *p) {	pReg = p; }

	int Search4Value( LPCTSTR lpszValueName);
	// TRUE = Install  FALSE = UnInstall
	BOOL Install( BOOL bInstall = TRUE);
	
	CSerializedValue*  GetValueObject(int nIndex) {
		if ((nIndex>=0) && (nIndex<values.GetSize()))
			return values.GetAt(nIndex);
		return NULL;
	}
protected:
	DECLARE_SERIAL(CSerializedKeyPath)

	CString strPath;
	BOOL bDeleteOnUnInstall;
	arrValues  values;
	CRegistry  *pReg;
};

//used in main object
typedef CArray<CSerializedKeyPath* ,CSerializedKeyPath*&> mapKeys;


/////////////////////////////////////////////////////////////////////////////
// CRegistrySerialize command target
class CRegistrySerialize : public CObject
{
public:
	CRegistrySerialize();
	virtual ~CRegistrySerialize();


#ifdef _DEBUG  //function to get info of map : shows a series of
	void Info(BOOL bShowValuesInfo = TRUE); //messageboxes with 
#endif //information (only in debug to reduce release size)

	BOOL InsertCSerializedKeyPath(CSerializedKeyPath *pNewPath);//for loading from archive

	//Loading maps from resources
	BOOL LoadFromResource(UINT uResourceID, LPCTSTR lpszResourceType);
	BOOL LoadFromResource(LPCTSTR lpszResourceName, LPCTSTR lpszResourceType);

	//format string into elements (see example of formating string to
	//series of ints (that represent RECT/POINT coordinates)
	BOOL FormatElement( LPCTSTR lpszBuffer,int iPosition , LPCTSTR lpszFormatSpecifier , LPVOID lpData);
	static BOOL FormatElements( LPCTSTR lpszBuffer, LPCTSTR lpszFormatSpecifier, 
			LPVOID lpData1 = NULL, LPVOID lpData2 = NULL, LPVOID lpData3 = NULL, LPVOID lpData4 = NULL, LPVOID lpData5 = NULL, 
			LPVOID lpData6 = NULL, LPVOID lpData7 = NULL, LPVOID lpData8 = NULL, LPVOID lpData9 = NULL, LPVOID lpData10 = NULL);

	// functions to be used when building the map
	BOOL InsertPath( LPCTSTR lpszRegistryPath, BOOL bDelete = TRUE);
	BOOL InsertValue( LPCTSTR lpszRegistryPath,
			LPCTSTR lpszValueName, REGDATA iDataType = REGSTRING ,	
			BOOL bDeleteOnUnInstall = TRUE);
	//If you find using enumeration hard use bare strings of types
	//supported types are those supported in REGDATA
	BOOL InsertValue( LPCTSTR lpszRegistryPath ,LPCTSTR lpszValueName,
			LPCTSTR lpszDataType = _T("CString"),	
			BOOL bDeleteOnUnInstall = TRUE);

	BOOL Install( BOOL bInstall = TRUE);
	BOOL UnInstall() {
		return Install(FALSE);
	}

	/////// Functions to be used in the script
	//of loading or saving
	BOOL Path( LPCTSTR lpszRegistryPath);
	BOOL Value( LPCTSTR lpszValueName, CString *pstrDest, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, DWORD *dwDest, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, int *iDest, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, float *pfDest, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, CPoint *pPoint, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, CRect *pRect, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, CSize *pSize, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, CTime *ptDest, BOOL bLoading = TRUE);
	BOOL Value( LPCTSTR lpszValueName, LPBYTE *lpByte,DWORD cbBuffLen, BOOL bLoading = TRUE);

public:
	void Serialize(LPCTSTR lpszFileName, BOOL bLoading = TRUE);
	void Serialize(CArchive &ar);
protected:
	void InternalSerialize(CArchive &ar);

	DECLARE_SERIAL(CRegistrySerialize)

	int SearchPath( LPCTSTR lpszRegistryPath);
	CSerializedValue* GetValueObject(LPCTSTR lpszValueName);
	void Destroy();

	CString strLastInsertedPath;
	CRegistry  reg;
	mapKeys  keys;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REGISTRYSERIALIZE_H__A5E77AA7_705C_11D4_B8C4_9439EECEC459__INCLUDED_)
