
/*++

Module Name:

    kill_prog.c

Abstract:

    This module contains common APIs to kill process:
		KillByNames
		EnableDebugPrivNT
		KillProcess
--*/


#include <windows.h>
#include <winperf.h>   // for Windows NT
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "kill_proc.h"

BOOL KillByNames( VOID );
BOOL EnableDebugPrivNT( VOID );
BOOL KillProcessById(DWORD dwProcessId);

BOOL
KillByNames(
	VOID
	)
{
	CHAR	ProgramName[NAME_SIZE][PROCESS_SIZE];
	BOOL	IsKilled[NAME_SIZE];
	DWORD	dwProcessId;
	DWORD	dwI;
	CHAR	TempName[PROCESS_SIZE];

	//
	// uniware: following codes are copied from GetTaskListNT()
	//
    DWORD                        rc;
    HKEY                         hKeyNames;
    DWORD                        dwType;
    DWORD                        dwSize;
    LPSTR                        buf = NULL;
    CHAR                         szSubKey[1024];
    LANGID                       lid;
    LPSTR                        p;
    LPSTR                        p2;
    PPERF_DATA_BLOCK             pPerf;
    PPERF_OBJECT_TYPE            pObj;
    PPERF_INSTANCE_DEFINITION    pInst;
    PPERF_COUNTER_BLOCK          pCounter;
    PPERF_COUNTER_DEFINITION     pCounterDef;
    DWORD                        i;
    DWORD                        dwProcessIdTitle;
    DWORD                        dwProcessIdCounter;
    CHAR                         szProcessName[MAX_PATH];

	//
	// uniware: read program names from config file ??? 
	// not support now, but you must init ProgramName[].
	//
	for ( dwI=0; dwI<NAME_SIZE; dwI++) {
		strcpy( ProgramName[dwI], "");
		IsKilled[dwI] = FALSE;
	}

	//
	// uniware: give program name by hard code
	//
	strcpy( ProgramName[0], "dccman");

	//
	// uniware: let this process have the power to kill
	//
	//if ( !EnableDebugPrivNT() )
	//	return FALSE;

    //
    // Look for the list of counters.  Always use the neutral
    // English version, regardless of the local language.  We
    // are looking for some particular keys, and we are always
    // going to do our looking in English.  We are not going
    // to show the user the counter names, so there is no need
    // to go find the corresponding name in the local language.
    //
    lid = MAKELANGID( LANG_ENGLISH, SUBLANG_NEUTRAL );	// MACRO
    sprintf( szSubKey, "%s\\%03x", REGKEY_PERF, lid );
	// Open key in register, hKeyNames holds the handle.
    rc = RegOpenKeyEx( HKEY_LOCAL_MACHINE,
                       szSubKey,
                       0,
                       KEY_READ,
                       &hKeyNames
                     );
    if (rc != ERROR_SUCCESS) {
        goto exit;
    }

    //
    // get the buffer size for the "counter" names,
	// pay attention to the usage of RegQueryValueEx()
    //
    rc = RegQueryValueEx( hKeyNames,
                          REGSUBKEY_COUNTERS,
                          NULL,
                          &dwType,
                          NULL,
                          &dwSize
                        );

    if (rc != ERROR_SUCCESS) {
        goto exit;
    }

    //
    // allocate the counter names buffer and set zeros.
    //
    buf = (LPSTR) malloc( dwSize );
    if (buf == NULL)
        goto exit;
    memset( buf, 0, dwSize );

    //
    // read the counter names from the registry
    //
    rc = RegQueryValueEx( hKeyNames,
                          REGSUBKEY_COUNTERS,
                          NULL,
                          &dwType,
                          (LPBYTE) buf,
                          &dwSize
                        );

    if (rc != ERROR_SUCCESS) {
        goto exit;
    }

    //
    // now loop thru the counter names looking for the following counters:
    //
    //      1.  "Process"           process name
    //      2.  "ID Process"        process id
    //
    // the buffer contains multiple null terminated strings and then
    // finally null terminated at the end.  the strings are in pairs of
    // counter number and counter name.
    //

    p = buf;
    while (*p) {
        if (p > buf) {
            for( p2=p-2; isdigit(*p2); p2--) ;
		}
		
        if (stricmp(p, PROCESS_COUNTER) == 0) {			// Look for string "process"
            //
            // look backwards for the counter number
            //
            for( p2=p-2; isdigit(*p2); p2--) ;
            strcpy( szSubKey, p2+1 );
        } else if (stricmp(p, PROCESSID_COUNTER) == 0) { // Look for string "id process"
            //
            // look backwards for the counter number
            //
            for( p2=p-2; isdigit(*p2); p2--) ;
            dwProcessIdTitle = atol( p2+1 );
        }
        //
        // next string
        //
        p += (strlen(p) + 1);
    }

    //
    // free the counter names buffer
    //
    free( buf );


    //
    // allocate the initial buffer for the performance data
    //
    dwSize = INITIAL_SIZE;
    buf = (LPSTR) malloc( dwSize );
    if (buf == NULL) {
        goto exit;
    }
    memset( buf, 0, dwSize );


    while (TRUE) {
		//
		// System reserved, need not open. defined in <winreg.h>.
		// 
        rc = RegQueryValueEx( HKEY_PERFORMANCE_DATA,
                              szSubKey,
                              NULL,
                              &dwType,
                              (LPBYTE) buf,
                              &dwSize
                            );

        pPerf = (PPERF_DATA_BLOCK) buf;

        //
        // check for success and valid perf data block signaturerege
        //
        if ((rc == ERROR_SUCCESS) &&
            (dwSize > 0) &&
            (pPerf)->Signature[0] == (WCHAR)'P' &&
            (pPerf)->Signature[1] == (WCHAR)'E' &&
            (pPerf)->Signature[2] == (WCHAR)'R' &&
            (pPerf)->Signature[3] == (WCHAR)'F' ) {
            break;
        }

        //
        // if buffer is not big enough, reallocate and try again
        //
        if (rc == ERROR_MORE_DATA) {
            dwSize += EXTEND_SIZE;
            buf = (LPSTR) realloc( buf, dwSize );
            memset( buf, 0, dwSize );
        }
        else {
            goto exit;
        }
    }

    //
    // set the perf_object_type pointer
    //
    pObj = (PPERF_OBJECT_TYPE) ((DWORD)pPerf + pPerf->HeaderLength);

    //
    // loop thru the performance counter definition records looking
    // for the process id counter and then save its offset
    //
    pCounterDef = (PPERF_COUNTER_DEFINITION) ((DWORD)pObj + pObj->HeaderLength);
    for (i=0; i<(DWORD)pObj->NumCounters; i++) {
        if (pCounterDef->CounterNameTitleIndex == dwProcessIdTitle) {
            dwProcessIdCounter = pCounterDef->CounterOffset;
            break;
        }
        pCounterDef++;
    }

    pInst = (PPERF_INSTANCE_DEFINITION) ((DWORD)pObj + pObj->DefinitionLength);

    //
    // loop thru the performance instance data extracting each process name
    // and process id
    //
    for (i=0; i < (DWORD)pObj->NumInstances; i++)
	{
        //
        // pointer to the process name
        //
        p = (LPSTR) ((DWORD)pInst + pInst->NameOffset);

        //
        // convert it to ascii
        //
        rc = WideCharToMultiByte( CP_ACP,
                                  0,
                                  (LPCWSTR)p,
                                  -1,
                                  szProcessName,
                                  sizeof(szProcessName),
                                  NULL,
                                  NULL
                                );

        if (!rc) {
            //
		    // if we cant convert the string then use a default value
            // uniware: skip it
			//
			strcpy(szProcessName, UNKNOWN_TASK);
        }

        //
        // get the process id
        //
        pCounter = (PPERF_COUNTER_BLOCK) ((DWORD)pInst + pInst->ByteLength);
        dwProcessId = *((LPDWORD) ((DWORD)pCounter + dwProcessIdCounter));
        if ( dwProcessId == 0) {
            dwProcessId = (DWORD)-2;
        }

		//
		// uniware: check if the process is in our victim list
		//
		for ( dwI=0; dwI<NAME_SIZE, !IsKilled[dwI]; dwI++ ) {
			if ( strcmp( szProcessName, "") == 0)
				continue;
			strcpy( TempName, ProgramName[dwI]);
			if ( stricmp( TempName, szProcessName ) == 0) {
				IsKilled[dwI] = KillProcessById( dwProcessId );
			} else if ( strlen(TempName)+4 <= NAME_SIZE ) {
				strcat( TempName, ".exe");
				if ( stricmp( TempName, szProcessName ) == 0) {
					IsKilled[dwI] = KillProcessById( dwProcessId );
				}
			}
		}
		//
        // next process
        //
        pInst = (PPERF_INSTANCE_DEFINITION) ((DWORD)pCounter + pCounter->ByteLength);
    }

exit:
    if (buf) {
        free( buf );
    }

    RegCloseKey( hKeyNames );
    RegCloseKey( HKEY_PERFORMANCE_DATA );

    return TRUE;
}

/*++

Routine Description:

    Changes the process's privilege so that kill works properly.

Arguments:


Return Value:

    TRUE             - success
    FALSE            - failure

--*/


BOOL
EnableDebugPrivNT(
    VOID
    )
{
    HANDLE hToken;
    LUID DebugValue;
    TOKEN_PRIVILEGES tkp;


    //
    // Retrieve a handle of the access token
    //
    if (!OpenProcessToken(GetCurrentProcess(),
            TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
            &hToken)) {
        printf("OpenProcessToken failed with %d\n", GetLastError());
        return FALSE;
    }

    //
    // Enable the SE_DEBUG_NAME privilege
    //
    if (!LookupPrivilegeValue((LPSTR) NULL,
            SE_DEBUG_NAME,
            &DebugValue)) {
        printf("LookupPrivilegeValue failed with %d\n", GetLastError());
        return FALSE;
    }

    tkp.PrivilegeCount = 1;
    tkp.Privileges[0].Luid = DebugValue;
    tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken,
        FALSE,
        &tkp,
        sizeof(TOKEN_PRIVILEGES),
        (PTOKEN_PRIVILEGES) NULL,
        (PDWORD) NULL);

    //
    // The return value of AdjustTokenPrivileges can't be tested
    //
    if (GetLastError() != ERROR_SUCCESS) {
        printf("AdjustTokenPrivileges failed with %d\n", GetLastError());
        return FALSE;
    }

    return TRUE;
}


BOOL KillProcessById(DWORD dwProcessId)
{
    HANDLE            hProcess;

	//
	// Force the process to terminate.
	//
    hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, dwProcessId );
    if (hProcess) {
        if (!TerminateProcess( hProcess, 1 )) 
		{
            CloseHandle( hProcess );
            return FALSE;
        }

        CloseHandle( hProcess );
        return TRUE;
    }

    return FALSE;
}


int main(void)
{
	EnableDebugPrivNT( );
	KillByNames();
/*
	DWORD dwNumTasks = 2048;
	STaskList refList[2048];
	DWORD i;
	// Init 


	GetTaskListNT(dwNumTasks, refList);

	for ( i=0; i<dwNumTasks; i++) {
		if ( stricmp(refList[i].ProcessName, "dccman.exe") == 0)
			printf("mm");
	}
*/
	return 0;
}