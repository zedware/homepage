
#ifndef PB_KILL_PROC_H
#define PB_KILL_PROC_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define TITLE_SIZE          64			// windows title's maximum length
#define PROCESS_SIZE        MAX_PATH	// process name's maximum length
#define NAME_SIZE			2			// max number of process to be killed

//
// manafest constants
//
#define INITIAL_SIZE        51200
#define EXTEND_SIZE         25600
#define REGKEY_PERF         "software\\microsoft\\windows nt\\currentversion\\perflib"
#define REGSUBKEY_COUNTERS  "Counters"
#define PROCESS_COUNTER     "process"
#define PROCESSID_COUNTER   "id process"
#define UNKNOWN_TASK        "unknown"

#endif // PB_KILL_PROC_H
