// NTService.h

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include "ntservice.h"
