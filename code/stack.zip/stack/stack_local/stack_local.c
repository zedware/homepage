
/*
 * Allocate too much memory from stack will cause stack overflow.  
 */

#include <stdio.h>

int main(int argc, char *argv[])
{
	int foo[1000000];
	return 0;
}
