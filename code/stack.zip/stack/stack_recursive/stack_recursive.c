
/*
 * Infinite recursive calls will lead to stack overflow soon.
 */

#include <stdio.h>

static void foo(void);
static void bar(void);

int main(int argc, char *argv[])
{
	foo();
	return 0;
}

static void foo(void)
{
    bar();
}

static void bar(void)
{
    foo();
}
