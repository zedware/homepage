#!/usr/bin/perl
#name:count.pl
#count the occurence of each input

use strict;
my %count;


while (<STDIN>) {
	chomp;		# chomp off the trailing new lines
	$count{$_}++;
}
while ( my ($key,$val) = each %count) {
	print "$key occurs $val time";
	if ( $val == 1) {
		print "\n";
	}
	else {
		print "s\n";
	}
}
	

