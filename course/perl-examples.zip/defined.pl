#!/usr/bin/perl

$madonna = <STDIN>;
if ( defined($madonna) ) { 
	print "The input was $madonna";
} else {
	print "No input available!\n";
}
