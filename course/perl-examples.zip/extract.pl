#!/usr/bin/perl

open INTERVAL, "<../shell/internalvariables.html";
open VARS,">vars.txt";

my $c=0;
while (<INTERVAL>) {
	$c++;
	if (/(CLASS="VARNAME")/) {
		if (<INTERVAL> =~ /\>(\$.+)\</) {
			print "============================";
			print VARS "$1\n";
		}
	}
}
print "c=$c";
