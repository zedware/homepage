#!/usr/bin/perl

print "\UHello World\E\n"; # This is a comment.