#my @all_files_including_dot = glob ".* *";
my @all_files_including_dot = glob "../shell/*";
foreach (@all_files_including_dot) {
 print;
 print "\n";
}
