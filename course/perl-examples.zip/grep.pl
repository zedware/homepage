#!/usr/bin/perl

my $what = shift @ARGV;

while (<>) {
	chomp;
	if (/($what)/) {
		print "I saw $what somewhere in |$`<$&>$'|\n";
	}
}
