#!/usr/bin/perl

$office = "global";  # Global $office
&say( );                                # says "global", accessing $office directly
 
&fred( );                               # says "fred", dynamic scope,
    # because fred's local $office hides the global
 
&barney( );                             # says "global", lexical scope;
    # barney's $office is visible only in that block
 
sub say { print "$office\n"; }         # print the currently visible $office
sub fred { local($office) = "fred"; &say( ); }
sub barney { my($office) = "barney"; &say( ); }
