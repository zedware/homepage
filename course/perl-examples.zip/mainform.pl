#!/usr/local/bin/perl 
# mailform - a simple CGI program to email the contents of an HTML 
#  form to a specified user. 

# Ben Johnson 
# johnsonb@ncsa.uiuc.edu 
# September, 1995 
################################################################ 
# Configuration parameters 
################################################################ 
# this program's name 
$progname = "mailform"; 

# the sendmail binary. 
$sendmail = "/usr/lib/sendmail"; 
 
# base of your httpd installation. 
$basedir = '/www'; 
# log file 
$logfile = "$basedir/etc/logs/$progname.log"; 
 
# today 
$date = `date`; 

chomp($date); 
# begin CGI output  
print("Content-type: text/html\n\n"); 

################################################################ 
# Process Query 
################################################################ 
@cgiPairs = split("&",$ENV{'QUERY_STRING'}); 

foreach $pair ( @cgiPairs ) { 
	($var,$val) = split("=",$pair); 
	#trust me on this magic. 
	$val =~ s/\+/ /g; 
	$val =~ s/%(..)/pack("c",hex($1))/ge; 
	$cgiVals{"$var"} = "$val"; 
} 
$recipient = $cgiVals{"to"}; 

# define an error routine: 
sub error { 
	($message) = @_; 
	print("<b>ERROR:<b>", 
		$message, 
		"<p>Contact the author of the previous page for assistance\n"); 
	exit(0); 
} 
if ( ! $recipient ) { 
	# the form did not have a to field 
	# modify this text appropriately 
	&error("No Return Address"); 
} 

################################################################ 
# Check Security 
################################################################ 
# Users who wish to use this program must 
# put the file ".allowmailform" in their home directory on the  
# machine running this script.  We don't want people creating 
# forms that are abused to send "anonymous" mail. 
$homedir = (getpwnam($recipient))[7]; 
if (! -e "$homedir/.allowmailform") { 
	# this user does not permit the server to send mail to him.  Quit. 
	&error("The recipient of the form has not enabled access for this form");    exit(0); 
} 

# get ready to send the mail 
if ( ! open(MAIL,"| $sendmail $recipient") ) { 
    &error("Could not start mail program"); 
} 

################################################################ 
# construct the headers 
################################################################ 
print(MAIL "To: recipient\n"); 
if ( ! $cgiVals{'subject'} ) { 
    $cgiVals{'subject'} = "(no subject)"; 
} 
print(MAIL "Subject: $cgiVals{subject}\n"); 
if ( ! $cgiVals{'from'} ) { 
    $cgiVals{'from'} = "nobody"; 
} 
print( MAIL "From: $cgiVals{from}\n"); 
# done with the headers.  Add the blank line. 
print( MAIL "\n"); 
 
################################################################ 
# construct the body 
################################################################ 
foreach $key ( keys(%cgiVals) ) { 
    if ( $key eq "to" || $key eq "subject" || $key eq "from" ) { 
	next; 
    }  
    print( MAIL "$key: $cgiVals{$key}\n"); 
} 
################################################################ 
# All done.  Clean up. 
################################################################ 
close(MAIL); 
# the response. 
print("Form submitted successfully.  Thanks!"); 
exit(0); 




