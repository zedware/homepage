#!/usr/bin/perl

my $dino = "I fear that I would be extinct after 1000 years.";
if ($dino =~ /(\d*) years/) {
	print "That said $1 years\n";
}

my $dino = "I fear that I would be extinct after a few million years";
if ( $dino =~ /(\d*) years/) {
	printf "That said $1 years\n";
}
