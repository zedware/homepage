#!/usr/bin/perl

while (<>) {
	chomp;
	if (/\w{8}/) {
		print "you have a word containing 8 characters\n";
	}
	else {
		print " you don't have any such words\n";
	}
}