#!/usr/bin/perl

print (2+3)*4;
