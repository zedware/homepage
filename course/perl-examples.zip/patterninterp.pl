#!/usr/bin/perl -w
my $what = "larry";
 
while (<>) {
  if (/^($what)/) {  # pattern is anchored at beginning of string
    print "We saw $what in beginning of $_";
  }
}
