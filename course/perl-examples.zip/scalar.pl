#!/usr/bin/perl

@rocks = qw( talc quartz jade obsidian );
print "How many rocks do you have?\n";
print "I have ", "@rocks", " rocks!\n"; 
	# WRONG, prints names of rocks
print "I have ", scalar @rocks, " rocks!\n"; 
	# Correct, gives a number
