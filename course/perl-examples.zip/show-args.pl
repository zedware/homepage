foreach $arg (@ARGV) {
print "one arg is $arg\n";
}
