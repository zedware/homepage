#!/usr/bin/perl

$_ = "green scale dinosaur\n";

if( s/(\w+) (\w+)/$2, $1/ ) {
	print ;
}
if (s/^/huge, /) {
	print;
}
print if (s/,.*een//);
print if (s/green/red/);
print if (s/\w+$/($`!)$&/);
print if (s/\s+(!\W+)/$1 /);
print if (s/huge/giantic/g);
