#!/usr/bin/perl

print sort  <>
