#!/usr/bin/perl
$string = "\xAA" | "\x55";
print time;
print $string;