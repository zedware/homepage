#!/usr/bin/perl

$_ = "I saw fred and barney";
print if (s/(fred|barney)/\u$1/gi);
