#!/bin/bash
# name:backups
# to call:backups [-q] [-d device] 
QUIET=n
DEVICE=awa
LOGFILE=/tmp/logbackup

usage()
{
	echo "Usage:`basename $0` [-d devide] [-l logfile] [-q]"
	exit 1
}

if [ $# -eq 0 ]
then
	usage
fi

while getopts :qd:l: OPTION 
do
	case $OPTION in 
	q)	QUIET=y
		LOGFILE=/tmp/backup.log
		;;
	d)	DEVICE=$OPTARG
		;;
	l)	LOGFILE=$OPTARG
		;;
	\?)	usage
		;;
	esac
done

echo "you chose the following options..I can process these"
echo "Quiet=$QUIET	$DEVICE		$LOGFILE"