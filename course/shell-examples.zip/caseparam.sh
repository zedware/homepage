#!/bin/bash
#caseparam

if [ $# != 1 ]
then
	echo "Usage: `basename $0` [start|stop|help]" >&2
	exit 1
fi

OPT=$1
case $OPT in
start) echo "starting ..`basename $0`"
	   #Code here to start a process
	   ;;
stop) echo "stopping .. `basename $0`"
	  #Code here to stop a process
	  ;;
help) 
	  #Code here to display a help page
	  ;;
*) echo "Usage: `basename $0` [start|stop|help]"
	  ;;
esac