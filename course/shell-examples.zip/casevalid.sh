#!/bin/bash
#casevalid

TYPE=""
echo -n "Enter the dept no:"
read DEPT
case $DEPT in
	234);;
	345);;
	544);;
	123);;
	*) echo "`basename $0`: Unknown dept no:" >&2
	   echo "try.. 234, 345, 544, 123"
	   exit 1;;
	esac
	
echo "1	.	post"
echo "2	.	prior"
echo -n "enter the type of report"
read ANS_TYPE
case $ANS_TYPE in
	1)TYPE=post;;
	2)TYPE=prior;;
	*) echo "`basename $0` : Unknown report type:" >&2
		exit 2;;
esac
	
	
echo "Now running report for dept $DEPT for the type $TYPE"
#run the command report