#!/bin/bash
#child script

echo "called form father..I am the child"
echo "film name is: $FILM"
FILM="Titanic"
echo "changing film to $FILM"
exit 123
