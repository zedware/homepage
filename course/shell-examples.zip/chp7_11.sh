#!/bin/bash

var1=20
var2=22

[ "$var1" -ne "$var2" ] && echo "$var1 is not equal to $var2"

home=/home/cw

[ -d "$home" ] || echo "$home directory does not exist."
