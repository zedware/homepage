#!/bin/bash

(( true ))
echo "Exit status of \"(( true ))\" is $?."

(( 0 )) 
echo "Exit status of \"(( 0 ))\" is $?."

(( (( 5 > 4 )) ))
echo "Exit status of \"(( (( 5 > 4 )) ))\" is $?."

(( 1 / 0 )) 
echo "Exit status of \"(( 1 / 0 ))\" is $?."
