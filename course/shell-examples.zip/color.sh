#!/bin/bash
# test for different colors
# format is [background;foregroundm
# to inout control characters:<ctrl-v><ESC>

echo "[40;32m"
echo "Hello World"

echo "[40;33m"
echo "Hellow World"

echo "[41;32m"
echo "Hello World"

echo "[37;40m"
echo "Hello World"
