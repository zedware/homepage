#!/bin/bash
#copyfile

FILENAME=myfile
FILENAME_BAK=myfile.bak

if [ -s FILENAME ] ; then
	exec 4>$FILENAME_BAK # open FILENAME_BAK for writing
	exec 3<$FILENAME	 # open FILENAME for reading
	
	while :
	do
		read LINE <&3
		if [ $? -ne 0 ]; then
			exec 3<&-
			exec 4>&-
			exit
		fi
		echo $LINE>&4
	done
else
	echo "`basename $0`: Sorry, $FILENAME is not present or is empty" >&2
fi