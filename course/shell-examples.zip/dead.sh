#!/bin/bash

var=1
while ($var=1 )
do
:
done
