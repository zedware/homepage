#!/bin/bash
# declare -x var=3
echo "var = $var"
(echo "from parenthesis:var = $var")
./check.sh