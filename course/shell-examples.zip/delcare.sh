#!/bin/bash
declare -i number
# The script will treat subsequent occurrences of "number" as an integer.		

number=3
echo "number = $number"     # number = 3

number=three
echo "number = $number"     # number = 0
# Tries to evaluate "three" as an integer.