#!/bin/bash
#direc_check
#source function file functions.sh
. /home/cw/shell/functions.sh

echo -n "enter destination directory:"
read DIREC
if is_it_a_directory $DIREC 
then :
else
	error_msg "$DIREC does not exist...creating it now"
	mkdir $DIREC > /dev/null 2>&1
	if [ $? != 0 ]
	then
		error_msg "Could not create directory: check it out!"
		exit 1
	else :
	fi
fi
echo "extracting files"

