#!/bin/bash
#demo for usage of echo command

var="This is a sentence.\\This, \another\."
echo $var
echo "$var"

IFS='\'
echo $var
echo "$var"
echo '$var'
