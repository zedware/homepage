#!/bin/bash
# name: echoself.sh
TMP=`basename $0`
#tr -s "\015" "\n" < `basename $0` > tmp 
declare -i LINES=`wc -l < $TMP`

while [ "$LINES" -gt "0" ] 
do 
	LOOP=`sed -n "$LINES p" $TMP`
	#echo "LOOP=$LOOP"
	#echo "LINES=$LINES"
	if [ -n "$LOOP" ]
	then
		POS=${#LOOP}	#`expr length $LOOP`
		#echo "POS=$POS"
		POS=$(($POS - 1))
		while [ "$POS" -ge "0" ]
			do
			echo -n ${LOOP:$POS:1}
			POS=$(($POS - 1))
		done
	fi
	echo
	LINES=$(($LINES - 1))
done
