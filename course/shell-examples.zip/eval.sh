#!/bin/bash
# name:eval.sh

while read QUOTA DATA
do
	eval ${QUOTA}=${DATA}
done < data

echo "You have a $PC pc, with a $MONITOR monitor"
echo "and are you network? $NETWORK"

