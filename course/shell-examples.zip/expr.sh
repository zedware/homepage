#!/bin/bash

a=`expr 3 + 5`
echo "3 + 5 = $a"

a=`expr 5 % 3`
echo "5 % 3 = $a"

a=`expr 5 \* 3`
echo "5 * 3 = $a"

