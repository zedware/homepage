#!/bin/bash
#father script

echo "This is the father"
FILM="Brave Heart"
export FILM
echo "I like the film: $FILM"
#call the child script
./child.sh
echo "the exit status of the preceding command is $?"
echo "back to father"
echo "and the film is $FILM"
echo "now the exit status is $?"
