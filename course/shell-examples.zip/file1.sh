#! /bin/bash
echo 1234567890 > File
exec 3<>File
read -n4 <&3
echo -n . >&3
exec 3>&-
cat File
