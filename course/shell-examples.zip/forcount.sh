#!/bin/bash
#forcount

counter=0
for files in *
do
	counter=`expr $counter + 1`
done

echo "There are $counter files in `pwd`"