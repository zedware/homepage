#!/bin/bash
#forcp

BAK=".bak"
for loop in `ls`
do
	echo "copying $loop to $loop$BAK"
	cp $loop $loop$BAK
done