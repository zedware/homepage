#!/bin/bash


for loop in `ls | grep -v [\.]`
do
	echo "Copying $loop to $loop.bak"
	cp $loop $loop.bak
done