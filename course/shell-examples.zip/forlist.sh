#!/bin/bash
#forlist

for loop in one two three four five
do
	echo "counting $loop"
done
