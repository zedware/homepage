#!/bin/bash
#formail

WHOS_ON=`who -u  | awk '{print $1}'`
for user in $WHO_ON
do 
	mail $user << END
	Dear Friend,
		It's weekend today. May you have a pleasant holidy.
		See you down the bar at 17:30 for a drink.
	See Ya.
	$USER
	END
done