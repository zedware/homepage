#!/bin/bash
#forparam.sh

for params
do
	echo "You supplied $params as a command line option"
done
echo $params