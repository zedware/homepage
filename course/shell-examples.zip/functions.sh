#!/bin/bash
#functions.sh
#main script functions


is_it_a_directory()
{
	# is_it_a_directory
	# to call:is_it_a_directory directory_name
	_DIRECTORY_NAME=$1
	if [ $# -lt 1 ] ;then
		echo "is_it_a_directory: I need a directory name to check"
		return 1
	fi
	#is it a directory?
	if [ ! -d $_DIRECTORY_NAME ]; then
		return 1
	else
		return 0
	fi
}

#-------------------------------------------
error_msg()
{
	# error_msg
	# beeps,display message;beep again!
	echo -e "\007"
	echo $@
	echo -e "\007"
	return 0
}