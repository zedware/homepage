#! /bin/bash
echo Hello World!
echo Goodbye World!
echo How Are You?
