#!/bin/bash
#ifelif

echo -n "Enter your name:"
read NAME

if [ -z $NAME ] || [ $NAME == "" ]; then
	echo "You did not enter a name"
elif [ $NAME = "root" ]; then
	echo "Hello root"
elif [ $NAME = "Sarah" ]; then
	echo "Hello Sarah"
elif [ $NAME = "Denny" ];then
	echo "Hello Denny"
else
	echo "You are not root or Sarah or Denny but hi $NAME"
fi
