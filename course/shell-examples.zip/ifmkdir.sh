#!/bin/bash
#ifmkdir
# parameter is passed as $1 but reassigned to DIRECTORY

DIRECTORY=$1
#is the string empty?
if [ -z DIRECTORY ]
then 
	echo "Usage: $(basename $0) directory to create" >&2
	exit 1
fi

if [ -d DIRECTORY ]
then :
else
	echo "The directory does not exist"
	set -x
	echo -n "Create it now? [y..n]"
	read ANS
	echo "&&&&&&&&&&&&&&Now ANS is $ANS &&&&&&&&&&&&&&&&&"
	if [ $ANS = Y ] || [ $ANS = y ]
	then
		echo "Creating now"
		#create directory and send all output to /dev/null
		mkdir $DIRECTORY &>/dev/null
		if [ $? != 0 ]; then
			echo "Error creating the directory $DIRECTORY" >&2
			exit 1
		fi
	else :
	fi
	set +x
	
fi