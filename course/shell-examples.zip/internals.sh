#!/bin/bash

WHOLEFILE=../perl/internalvars.txt
WHOLE=internals.txt
SH_SETVAR=sh_setvar.out
TMP=tmpfile
i=1

tr -s "[\015]" "\n" < $WHOLEFILE > $WHOLE
for LOOP in `cat $SH_SETVAR`
do

	#don't forget eval!
	eval sed '/$LOOP/d' $WHOLE > $TMP$i
	WHOLE=$TMP$i
	i=$(( i + 1 ))	
done

i=$(( i - 1 ))

j=1
while [ $j -lt $i ]
do
	echo "deleting file #$j"
	rm $TMP$j
	j=$(( j + 1 ))
done

echo "the final file is $TMP$i"