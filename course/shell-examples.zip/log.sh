#!/bin/bash
# name:log.sh

MYDATE=`date '+%d%m%y'`
#append MYDATE to the variable LOGFILE
LOGFILE=backuplog.$MYDATE
#create the file
> $LOGFILE
