
ls -l

