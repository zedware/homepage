#!/bin/bash

echo -n "First name:"
read name

echo -n "Middle name:"
read middle

echo -n "Last name:"
read surname

echo "Firstname*****Middlename*****Lastname"
echo -e "$name\t\t$middle\t\t$surname"
