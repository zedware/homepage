#!/bin/bash
# Using 'shift' to step through all the positional parameters.

#  Name this script something like shft,
#+ and invoke it with some parameters, for example
#          ./shft a b c def 23 skidoo

eval echo "\$$#"             # print the last argument

until [ -z "$1" ]  # Until all parameters used up...
do
  echo -n "$1 "
  shift
done



exit 0
