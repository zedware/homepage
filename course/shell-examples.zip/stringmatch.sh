#!/bin/bash
stringZ=abcABC123ABCabc
#       |------|

echo `expr match "$stringZ" 'bc[A-Z]*.2'`   # 8
echo `expr "$stringZ" : 'abc[A-Z]*.2'`       # 8

