
# !/bin/bash

variable=\
echo "$variable"

variable=\
hello
echo "$variable"

echo ++++++++++++++++++++++++++
variable=\ 
echo "$variable"

variable=\\
echo "$variable"

variable=\\\
echo "$variable"

