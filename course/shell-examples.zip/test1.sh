#!/bin/bash
variable=\\\
echo "$variable"
echo How Are You?
