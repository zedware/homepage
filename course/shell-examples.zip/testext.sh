#!/bin/bash
#test for file extension

if [ $# -eq 0 ]
then 
	echo "Usage $(basename $0) filename" >&2
	exit 1
fi

filename=$1

if [ ${filename##*.} != "txt" ]
then
	echo "File $1 is not a txt file!"
	exit 123
fi
