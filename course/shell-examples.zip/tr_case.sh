#!/bin/bash
# name:tr_case
# to call: tr_case -[l|u] file [files]
# convert files to either lower case or upper case

FILES=""
TRCASE=""
EXT=""
OPT=""

# get called when a conversion is failed
error_msg()
{
	_FILENAME=$1;
	echo "`basename $0`:Error the conversion failed on $_FILENAME"
}

if [ $# -eq 0 ]
then
	echo "For more info try `basename $0` --help"
	exit 1
fi

while [ $# -gt 0 ]
do
	case $1 in 
	# set the variavles based on what option is used
	-u|-U)	TRCASE=upper
		 	EXT=".UC"
		 	OPT=yes
		 	shift
		 	;;
	-l|-L)	TRCASE=lower
			EXT=".LC"
			OPT=yes
			shift
			;;
	--help)	echo "convert a file(s) to uppercase from lowercase"
			echo "convert a file(s) to lowercase from uppercase"
			echo "will convert all the characters according to the"
			echo "specified command option."
			echo "Where option is"
			echo "-l convert to lowercase"
			echo "-u convert to uppercase"
			echo "The original file(s) is not touched. A new file(s)"
			echo "will be created with either a .UC or .LC expansion"
			echo "Usage:$0 -[u|l] file [files]"
			exit 0
			;;
	-*)		echo "Usage:$0 -[u|l] file [files]"
			exit 1
			;;
	*)		# * will match all the files passed, just as in globbing
			if [ -f $1 ]
			then
				FILES=$FILES" "$1
			else
				echo "`basename $0`:Error cannot find the file $1"
				exit 1
			fi
			shift
			;;
	esac
	
done

# no options given ... help the user
if [ "$OPT" == "no" ]
then
	echo "`basename $0`:Error you need to specify an option. No action taken"
	echo "try `basename $0` --help"
	exit 1
fi

# now read in all the files
for LOOP in $FILES
do
	case $TRCASE in 
	upper)	cat $LOOP | tr "[a-z]" "[A-Z]" > $LOOP$EXT
			if [ $? != 0 ]
			then 
				error_msg $LOOP
			else
				echo "converted file called $LOOP$EXT"
			fi
			;;
	lower)	cat $LOOP | tr "[A-Z]" "[a-z]" > $LOOP$EXT
			if [ $? != 0 ]
			then 
				error_msg $LOOP
			else
				echo "converted file called $LOOP$EXT"
			fi
			;;
	esac
done