#!/bin/bash

echo
counter=1

until [ "$var1" = "end" ]     # while test "$var1" != "end"
do                             # also works.
  echo "Input variable #$counter (end to exit) "
  read var1                    # Not 'read $var1' (why?).
  echo "variable #$counter = $var1"   # Need quotes because of "#".
  counter=$(( counter + 1 ))
  # If input is 'end', echoes it here.
  # Does not test for termination condition until top of loop.
  
  echo
done  

exit 0