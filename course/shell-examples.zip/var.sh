#!/bin/bash
#variable=\
#echo "$variable"

variable=\
23skidoo
echo "$variable"

variable=\\
echo "$variable"


