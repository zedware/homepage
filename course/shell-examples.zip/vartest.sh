#!/bin/bash
#vartest
echo -n "What time do you wish to receive the magazine 13:00 :"
read TIME
echo "prefer to receive the magazine at ${TIME:=13:00} OK"
echo -n "Is it a monthly or a weekly magazine Monthly :"
read MAG_TYPE
echo "Magazine type is ${MAG_TYPE:=Monthly}"
echo "receive a $MAG_TYPE magzine at $TIME"
