#!/bin/bash

echo -n "please input:";
read;
echo "you just input $REPLY";
