#!/bin/bash
#whileread

echo "Type <CTRL_D> to terminate"
echo -n "Enter your most favorate file:"
while read FILM
do
	echo "Yeah, great film the $FILM"
done