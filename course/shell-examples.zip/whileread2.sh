#!/bin/bash
#whileread2

while read LINE
do
	echo $LINE
done < myfile