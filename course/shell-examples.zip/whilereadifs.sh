#!/bin/bash
#whilereadifs

SAVEDIFS=$IFS
IFS=:
while read NAME DEPT ID
do
	echo -e "$NAME\t $DEPT\t $ID"
done < names.txt
IFS=SAVEDIFS