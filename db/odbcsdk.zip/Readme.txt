
ODBC 3.0 SDK

Originally Distributed by Microsoft Corp. 
All projects are converted into VC6.0's format.
Lastest version may be found in Microsoft's Platform SDK.

uniware@zedware.org
