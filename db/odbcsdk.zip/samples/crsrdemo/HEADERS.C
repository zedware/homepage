/*--------------------------------------------------------------------------
  Headers.c -- Phraseology headers file

  This code is furnished on an as-is basis as part of the ODBC SDK and is
  intended for example purposes only.

--------------------------------------------------------------------------*/

// Includes ----------------------------------------------------------------
#include "headers.h"
